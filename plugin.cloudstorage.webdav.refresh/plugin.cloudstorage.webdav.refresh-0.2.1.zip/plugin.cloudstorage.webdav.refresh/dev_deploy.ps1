$AddonId = "plugin.cloudstorage.webdav.refresh"
$SourceDir = $PSScriptRoot

Write-Host "Detecting Kodi installation..."

# Possible paths for Kodi addons
# 1. Standard Windows Installer: %APPDATA%\Kodi\addons
# 2. Windows Store Version: %LOCALAPPDATA%\Packages\XBMCFoundation.Kodi_*\LocalCache\Roaming\Kodi\addons
$PossiblePaths = @(
    "$env:APPDATA\Kodi\addons", 
    "$env:LOCALAPPDATA\Packages\XBMCFoundation.Kodi_*\LocalCache\Roaming\Kodi\addons"
)

$KodiAddonsPath = $null

foreach ($PathPattern in $PossiblePaths) {
    # Expand wildcards (especially for Store version with random ID)
    $ResolvedPaths = @(Get-Item $PathPattern -ErrorAction SilentlyContinue)
    
    foreach ($Path in $ResolvedPaths) {
        if (Test-Path $Path.FullName) {
            $KodiAddonsPath = $Path.FullName
            break
        }
    }
    
    if ($KodiAddonsPath) {
        break
    }
}

if (-not $KodiAddonsPath) {
    Write-Error "Kodi addons directory not found. Please ensure Kodi is installed."
    Write-Host "Checked paths:"
    $PossiblePaths | ForEach-Object { Write-Host " - $_" }
    exit 1
}

Write-Host "Found Kodi addons directory: $KodiAddonsPath"
$TargetDir = Join-Path $KodiAddonsPath $AddonId

Write-Host "Deploying $AddonId to $TargetDir ..."

# Robocopy to mirror the directory
# /MIR : Mirror directory tree
# /XD  : Exclude directories
# /XF  : Exclude files
robocopy $SourceDir $TargetDir /MIR /XD .git .vscode __pycache__ .idea /XF dev_deploy.ps1 *.pyc *.log /R:2 /W:1

# Robocopy exit codes: 0=No changes, 1=Files copied, >8=Fail
if ($LASTEXITCODE -ge 8) {
    Write-Error "Deployment failed with exit code $LASTEXITCODE"
    exit 1
}

Write-Host "Deployment Complete."
