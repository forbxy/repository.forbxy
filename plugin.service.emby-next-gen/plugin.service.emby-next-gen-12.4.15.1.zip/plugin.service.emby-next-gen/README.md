# plugin.service.emby-next-gen

## ⚠️ Disclaimer / 免责声明 ⚠️


This is **NOT** the official repository for the `emby-next-gen` Kodi add-on. This is a personal project/fork containing custom modifications and optimizations.   
*Note: This specific branch/repository was primarily created to provide compatibility and support for the [vfs.stream.fast](https://github.com/forbxy/vfs.stream.fast) add-on.*

For official downloads, support, updates, and discussions, please visit the official Emby Kodi community forum at:
👉 **[https://emby.media/community/forum/185-emby-for-kodi-next-gen/](https://emby.media/community/forum/185-emby-for-kodi-next-gen/)**


本仓库**不是** `emby-next-gen` Kodi 插件的官方代码库。这是一个包含自定义修改和优化的个人项目/分支。  
*注：创建此分支/仓库的主要目的是为了支持并兼容 [vfs.stream.fast](https://github.com/forbxy/vfs.stream.fast) 插件。*

如需获取官方原版插件下载、技术支持、最新更新或参与讨论，请访问官方的 Emby Kodi 社区论坛：
👉 **[https://emby.media/community/forum/185-emby-for-kodi-next-gen/](https://emby.media/community/forum/185-emby-for-kodi-next-gen/)**
