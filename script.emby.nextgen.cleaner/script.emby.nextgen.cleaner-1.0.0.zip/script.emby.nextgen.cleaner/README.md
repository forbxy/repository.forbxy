# Emby Next Gen 卸载清理工具

使用说明：请先在 Emby Next Gen 插件中执行“恢复出厂设置”，然后卸载 Emby Next Gen 插件，最后运行本插件以彻底清理Emby Next Gen相关的配置残留。
