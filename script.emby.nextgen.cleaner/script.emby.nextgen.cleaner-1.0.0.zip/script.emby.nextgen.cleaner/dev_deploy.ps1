$addonName = "script.emby.nextgen.cleaner"
$sourceDir = $PSScriptRoot
$destDir = Join-Path $env:APPDATA "Kodi\addons\$addonName"

Write-Host "Deploying $addonName to Kodi addons directory..." -ForegroundColor Cyan
Write-Host "Source: $sourceDir"
Write-Host "Destination: $destDir"

# Create destination if it doesn't exist, otherwise clean it
if (Test-Path $destDir) {
    Write-Host "Cleaning existing deployment..."
    # Keep the folder but remove contents to avoid locking issues sometimes
    Remove-Item -Path "$destDir\*" -Recurse -Force -ErrorAction SilentlyContinue
} else {
    New-Item -ItemType Directory -Force -Path $destDir | Out-Null
}

# Items to exclude from deployment
$excludeItems = @(".git", ".vscode", "__pycache__", ".gitignore", "*.md", "*.ps1")

Write-Host "Copying files..."
Get-ChildItem -Path $sourceDir -Exclude $excludeItems | Copy-Item -Destination $destDir -Recurse -Force

Write-Host "Deployment complete!" -ForegroundColor Green
