# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import shutil
import xml.etree.ElementTree as ET

try:
    from xml.etree.ElementTree import indent
except ImportError:
    # Fallback for older python versions
    def indent(elem, level=0):
        i = "\n" + level*"  "
        if len(elem):
            if not elem.text or not elem.text.strip():
                elem.text = i + "  "
            if not elem.tail or not elem.tail.strip():
                elem.tail = i
            for elem in elem:
                indent(elem, level+1)
            if not elem.tail or not elem.tail.strip():
                elem.tail = i
        else:
            if level and (not elem.tail or not elem.tail.strip()):
                elem.tail = i

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE_PATH = xbmcvfs.translatePath('special://userdata/')
ADDONS_PATH = xbmcvfs.translatePath('special://home/addons/')
ADVANCED_SETTINGS_PATH = os.path.join(PROFILE_PATH, 'advancedsettings.xml')
SOURCES_PATH = os.path.join(PROFILE_PATH, 'sources.xml')
LIBRARY_PATH = os.path.join(PROFILE_PATH, 'library')

def clean_advanced_settings():
    if not os.path.exists(ADVANCED_SETTINGS_PATH):
        xbmc.log(f"[{ADDON_NAME}] advancedsettings.xml not found.", xbmc.LOGINFO)
        return False

    try:
        tree = ET.parse(ADVANCED_SETTINGS_PATH)
        root = tree.getroot()
        modified = False

        # 关键词，匹配 Emby Next Gen 生成的规则
        keywords = ['emby_addon_mode', '127.0.0.1:57342']

        # 1. 清理 pathsubstitution 里的匹配项
        path_sub = root.find('pathsubstitution')
        if path_sub is not None:
            subs_to_remove = []
            for sub in path_sub.findall('substitute'):
                from_elem = sub.find('from')
                if from_elem is not None and from_elem.text and any(k in from_elem.text for k in keywords):
                    subs_to_remove.append(sub)
            
            for sub in subs_to_remove:
                path_sub.remove(sub)
                modified = True
                xbmc.log(f"[{ADDON_NAME}] Removed substitute: {ET.tostring(sub, encoding='unicode').strip()}", xbmc.LOGINFO)
            
            # 如果 pathsubstitution 空了，连同节点一起删除
            if len(path_sub) == 0:
                root.remove(path_sub)
                modified = True

        # 2. 清理 video 和 audio 里的 excludefromlisting、excludefromscan 等
        for media_type in ['video', 'audio']:
            media_elem = root.find(media_type)
            if media_elem is not None:
                exclude_types = ['excludefromlisting', 'excludefromscan', 'excludetvshowsfromscan']
                for exclude_type in exclude_types:
                    exclude_elem = media_elem.find(exclude_type)
                    if exclude_elem is not None:
                        regexps_to_remove = []
                        for regexp in exclude_elem.findall('regexp'):
                            if regexp.text and any(k in regexp.text for k in keywords):
                                regexps_to_remove.append(regexp)
                        
                        for regexp in regexps_to_remove:
                            exclude_elem.remove(regexp)
                            modified = True
                            xbmc.log(f"[{ADDON_NAME}] Removed regexp from {exclude_type}: {regexp.text}", xbmc.LOGINFO)
                        
                        # 如果没有剩余的 regexps 则移除父节点
                        if len(exclude_elem) == 0:
                            media_elem.remove(exclude_elem)
                            modified = True
                
                # 如果 video/audio 子节点全空（没有有效子集）
                if len(media_elem) == 0:
                    root.remove(media_elem)
                    modified = True

        # 3. 清理 network 里的特定配置
        # Emby Next Gen 会添加禁用 http2 和 5 秒超时，如果仅有这两个配置并且我们前面已经确认有其他 Emby Next Gen生成的配置，则将其移除
        if modified:
            network_elem = root.find('network')
            if network_elem is not None:
                children = list(network_elem)
                # 只有当且仅当这两个属性存在，并且没有其他属性时才删除
                if len(children) == 2:
                    has_disablehttp2 = any(child.tag == 'disablehttp2' and child.text == 'true' for child in children)
                    has_curlclienttimeout = any(child.tag == 'curlclienttimeout' and child.text == '5' for child in children)
                    if has_disablehttp2 and has_curlclienttimeout:
                        root.remove(network_elem)
                        # modified 已经是 True，这里不需要重复赋值
                        xbmc.log(f"[{ADDON_NAME}] Removed specific network settings injected by Emby Next Gen.", xbmc.LOGINFO)

        if modified:
            try:
                indent(tree, space="    ", level=0)
            except TypeError:
                indent(root)
            tree.write(ADVANCED_SETTINGS_PATH, encoding='utf-8', xml_declaration=True)
            xbmc.log(f"[{ADDON_NAME}] Successfully cleaned advancedsettings.xml.", xbmc.LOGINFO)
            return True
        else:
            xbmc.log(f"[{ADDON_NAME}] No Emby Next Gen residuals found in advancedsettings.xml.", xbmc.LOGINFO)
            return False

    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error cleaning advancedsettings.xml: {e}", xbmc.LOGERROR)
        return False

def clean_sources():
    if not os.path.exists(SOURCES_PATH):
        xbmc.log(f"[{ADDON_NAME}] sources.xml not found.", xbmc.LOGINFO)
        return False

    try:
        tree = ET.parse(SOURCES_PATH)
        root = tree.getroot()
        modified = False

        keywords = ['emby-for-kodi-next-gen-addon', 'emby_addon_mode', '127.0.0.1:57342']

        # sources.xml contains categories like <video>, <music>, <pictures>, <files>, <programs>
        for category in root:
            sources_to_remove = []
            for source in category.findall('source'):
                should_remove = False
                
                # Check source name
                name_elem = source.find('name')
                if name_elem is not None and name_elem.text and any(k in name_elem.text.lower() for k in keywords):
                    should_remove = True
                
                # Check source path
                path_elem = source.find('path')
                if path_elem is not None and path_elem.text and any(k in path_elem.text.lower() for k in keywords):
                    should_remove = True

                if should_remove:
                    sources_to_remove.append(source)

            for source in sources_to_remove:
                category.remove(source)
                modified = True
                source_name = source.find('name').text if source.find('name') is not None else 'Unknown'
                xbmc.log(f"[{ADDON_NAME}] Removed source '{source_name}' from category '{category.tag}'.", xbmc.LOGINFO)

        if modified:
            try:
                indent(tree, space="    ", level=0)
            except TypeError:
                indent(root)
            tree.write(SOURCES_PATH, encoding='utf-8', xml_declaration=True)
            xbmc.log(f"[{ADDON_NAME}] Successfully cleaned sources.xml.", xbmc.LOGINFO)
            return True
        else:
            xbmc.log(f"[{ADDON_NAME}] No Emby Next Gen residuals found in sources.xml.", xbmc.LOGINFO)
            return False

    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error cleaning sources.xml: {e}", xbmc.LOGERROR)
        return False

def clean_library():
    if not os.path.exists(LIBRARY_PATH):
        xbmc.log(f"[{ADDON_NAME}] library folder not found.", xbmc.LOGINFO)
        return False

    cleaned = False
    try:
        for root, dirs, files in os.walk(LIBRARY_PATH, topdown=False):
            # 1. 检查并删除特定前缀的文件夹
            for dir_name in dirs:
                dir_lower = dir_name.lower()
                if dir_lower.startswith('emby_') or dir_lower.startswith('emby_downloaded_') or dir_lower.startswith('emby_favorite_'):
                    dir_path = os.path.join(root, dir_name)
                    try:
                        shutil.rmtree(dir_path)
                        xbmc.log(f"[{ADDON_NAME}] Removed directory: {dir_path}", xbmc.LOGINFO)
                        cleaned = True
                    except Exception as e:
                        xbmc.log(f"[{ADDON_NAME}] Failed to remove directory {dir_path}: {e}", xbmc.LOGERROR)

            # 2. 检查并删除 xml 文件
            for file_name in files:
                if file_name.endswith('.xml'):
                    file_path = os.path.join(root, file_name)
                    
                    file_lower = file_name.lower()
                    if file_lower.startswith('emby_downloaded_') or file_lower.startswith('emby_favorite_'):
                        try:
                            os.remove(file_path)
                            xbmc.log(f"[{ADDON_NAME}] Removed XML file (name prefix match): {file_path}", xbmc.LOGINFO)
                            cleaned = True
                        except Exception as e:
                            xbmc.log(f"[{ADDON_NAME}] Failed to remove XML {file_path}: {e}", xbmc.LOGERROR)
                        continue
                    
                    # 检查里面是否有 emby 的特征路径
                    try:
                        tree = ET.parse(file_path)
                        xml_root = tree.getroot()
                        path_elem = xml_root.find('path')
                        if path_elem is not None and path_elem.text:
                            # 根据要求检查包含 lugin://plugin.service.emby-next-gen
                            # （实际中也有可能是 plugin://plugin.service.emby-next-gen）
                            text = path_elem.text.lower()
                            if 'plugin.service.emby-next-gen' in text:
                                os.remove(file_path)
                                xbmc.log(f"[{ADDON_NAME}] Removed XML file (path match): {file_path}", xbmc.LOGINFO)
                                cleaned = True
                    except Exception as parse_e:
                        pass # 忽略非标准的 xml 解析错误

        if cleaned:
            xbmc.log(f"[{ADDON_NAME}] Successfully cleaned library folder.", xbmc.LOGINFO)
        else:
            xbmc.log(f"[{ADDON_NAME}] No Emby Next Gen residuals found in library folder.", xbmc.LOGINFO)
        return cleaned

    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error cleaning library folder: {e}", xbmc.LOGERROR)
        return False

def clean_stub_addons():
    addons_to_remove = [
        'plugin.audio.emby-next-gen',
        'plugin.image.emby-next-gen',
        'plugin.video.emby-next-gen'
    ]
    cleaned = False

    for addon_id in addons_to_remove:
        addon_dir = os.path.join(ADDONS_PATH, addon_id)
        if os.path.exists(addon_dir) and os.path.isdir(addon_dir):
            try:
                shutil.rmtree(addon_dir)
                xbmc.log(f"[{ADDON_NAME}] Removed stub addon: {addon_id}", xbmc.LOGINFO)
                cleaned = True
            except Exception as e:
                xbmc.log(f"[{ADDON_NAME}] Failed to remove stub addon {addon_id}: {e}", xbmc.LOGERROR)

    return cleaned

def main():
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Emby Next Gen 清理工具", "是否开始扫描并清理 Emby Next Gen 在 advancedsettings、sources、library 等等中的配置和残留插件？"):
        cleaned_advanced = clean_advanced_settings()
        cleaned_sources = clean_sources()
        cleaned_lib = clean_library()
        cleaned_stubs = clean_stub_addons()
        
        if cleaned_advanced or cleaned_sources or cleaned_lib or cleaned_stubs:
            dialog.ok("清理完成", "已成功清理 Emby Next Gen 的相关配置残留和存根插件。 \n请重启 Kodi 生效。")
        else:
            dialog.ok("清理结果", "未发现需要清理的残留项或已清理干净。")

if __name__ == '__main__':
    main()
