# -*- coding: utf-8 -*-
"""
直接数据库访问层，用于读写 bookmark.playerState 字段。
JSON-RPC 的 SetMovieDetails/SetEpisodeDetails 在更新续播进度时会将 playerState 清空，
故需要在 JSON-RPC 写回后通过此模块直接写库恢复 playerState（ISO 蓝光轨道信息等）。

自动检测 Kodi 视频数据库类型：
- 若 advancedsettings.xml 中配置了 MySQL，则连接 MySQL（通过 pymysql）
- 否则自动连接本地 SQLite（special://database/MyVideos*.db）
"""

import os
import re
import sqlite3
import traceback
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs

from lib.common import log

_conn = None
_is_mysql = False


# ---------------------------------------------------------------------------
# MySQL 配置自动检测（参考 tmdb 刮削器写法）
# ---------------------------------------------------------------------------

def _parse_mysql_from_xml(xml_path):
    """从单个 advancedsettings.xml 解析 MySQL 视频数据库配置，返回 dict 或 None。"""
    try:
        if not xbmcvfs.exists(xml_path):
            return None
        tree = ET.parse(xml_path)
        root = tree.getroot()
        vdb = root.find('videodatabase')
        if vdb is None:
            return None
        if vdb.findtext('type', '').strip().lower() != 'mysql':
            return None
        host = vdb.findtext('host', '').strip()
        user = vdb.findtext('user', '').strip()
        if not host or not user:
            log(f'MySQL config incomplete in {xml_path}', xbmc.LOGWARNING)
            return None
        return {
            'host': host,
            'port': int(vdb.findtext('port', '3306').strip()),
            'user': user,
            'password': vdb.findtext('pass', '').strip(),
            'database': vdb.findtext('name', '').strip(),
        }
    except Exception:
        log(f'Error parsing {xml_path} for MySQL:\n{traceback.format_exc()}', xbmc.LOGWARNING)
        return None


def _get_mysql_config():
    """
    读取 advancedsettings.xml，检查 Kodi 是否配置了 MySQL 视频数据库。
    返回 {host, port, user, password, database} 或 None。
    自动检测实际数据库名（Kodi 会在名字后追加 schema 版本号）。
    """
    result = None
    for special_path in ('special://userdata/advancedsettings.xml',
                         'special://profile/advancedsettings.xml'):
        cfg = _parse_mysql_from_xml(xbmcvfs.translatePath(special_path))
        if cfg:
            result = cfg  # profile 覆盖 userdata（与 Kodi 行为一致）

    if not result:
        return None

    base_name = result['database'] if result['database'] else 'MyVideos'

    # 尝试连接 MySQL 探测实际带版本号的数据库名
    try:
        import pymysql
        tmp = pymysql.connect(
            host=result['host'], port=result['port'],
            user=result['user'], password=result['password'],
            connect_timeout=5,
        )
        try:
            with tmp.cursor() as cur:
                cur.execute('SHOW DATABASES LIKE %s', (base_name + '%',))
                dbs = [row[0] for row in cur.fetchall()]
            if dbs:
                pattern = re.escape(base_name) + r'(\d+)'
                def _ver(n):
                    m = re.search(pattern, n)
                    return int(m.group(1)) if m else 0
                best = max(dbs, key=_ver)
                if _ver(best) > 0:
                    result['database'] = best
        finally:
            tmp.close()
    except Exception:
        log(f'Failed to detect MySQL video DB version:\n{traceback.format_exc()}',
            xbmc.LOGWARNING)
        if not result['database']:
            result['database'] = 'MyVideos131'

    log(f'MySQL video database detected: {result["host"]}:{result["port"]}/{result["database"]}',
        xbmc.LOGINFO)
    return result


# ---------------------------------------------------------------------------
# SQLite 路径检测
# ---------------------------------------------------------------------------

def _get_sqlite_path():
    """返回最新的本地 MyVideos*.db 路径，或 None。"""
    db_dir = xbmcvfs.translatePath('special://database')
    try:
        _, files = xbmcvfs.listdir(db_dir)
    except Exception:
        log(f'Cannot list database dir {db_dir}:\n{traceback.format_exc()}', xbmc.LOGWARNING)
        return None
    video_dbs = [f for f in files if f.startswith('MyVideos') and f.endswith('.db')]
    if not video_dbs:
        return None

    def _ver(name):
        m = re.search(r'MyVideos(\d+)\.db', name)
        return int(m.group(1)) if m else 0

    return os.path.join(db_dir, max(video_dbs, key=_ver))


# ---------------------------------------------------------------------------
# 连接管理
# ---------------------------------------------------------------------------

def _get_conn():
    """获取或创建数据库连接（自动选择 MySQL 或 SQLite）。"""
    global _conn, _is_mysql

    # 复用已有连接
    if _conn is not None:
        if _is_mysql:
            try:
                _conn.ping(reconnect=True)
                return _conn
            except Exception:
                _conn = None
        else:
            return _conn  # SQLite 连接不需要 ping

    # 优先尝试 MySQL（通过 advancedsettings.xml 自动检测）
    mysql_cfg = _get_mysql_config()
    if mysql_cfg:
        try:
            import pymysql
            _conn = pymysql.connect(
                host=mysql_cfg['host'],
                port=mysql_cfg['port'],
                user=mysql_cfg['user'],
                password=mysql_cfg['password'],
                database=mysql_cfg['database'],
                charset='utf8mb4',
                autocommit=True,
                connect_timeout=5,
            )
            _is_mysql = True
            log(f'DB connected (MySQL): {mysql_cfg["host"]}:{mysql_cfg["port"]}'
                f'/{mysql_cfg["database"]}')
            return _conn
        except Exception:
            log(f'MySQL connection failed:\n{traceback.format_exc()}', xbmc.LOGERROR)
            return None

    # 回退到本地 SQLite
    sqlite_path = _get_sqlite_path()
    if not sqlite_path:
        log('No video database found (neither MySQL nor SQLite)', xbmc.LOGWARNING)
        return None
    try:
        _conn = sqlite3.connect(sqlite_path, check_same_thread=False)
        _is_mysql = False
        log(f'DB connected (SQLite): {sqlite_path}')
        return _conn
    except Exception:
        log(f'SQLite connection failed:\n{traceback.format_exc()}', xbmc.LOGERROR)
        return None


# ---------------------------------------------------------------------------
# 查询 / 更新
# ---------------------------------------------------------------------------

def get_all_played_movies():
    """
    查询所有有播放记录或续播进度的电影。
    返回列表，每条记录：{movieid, idFile, tmdb_id, title, playcount, lastplayed,
                          resume_position, resume_total, player_state}
    """
    conn = _get_conn()
    if not conn:
        return None
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.idMovie,
                   m.idFile,
                   uid.value AS tmdb_id,
                   m.c00 AS title,
                   f.playCount,
                   f.lastPlayed,
                   b.timeInSeconds AS resume_position,
                   b.totalTimeInSeconds AS resume_total,
                   b.playerState AS player_state
            FROM movie m
            JOIN files f ON f.idFile = m.idFile
            JOIN uniqueid uid ON uid.media_id = m.idMovie
                              AND uid.media_type = 'movie'
                              AND uid.type = 'tmdb'
            LEFT JOIN bookmark b ON b.idFile = m.idFile AND b.type = 1
            WHERE f.playCount > 0
               OR (f.lastPlayed IS NOT NULL AND f.lastPlayed != '')
               OR b.idBookmark IS NOT NULL
        """)
        rows = cursor.fetchall()
        cursor.close()
        result = []
        for row in rows:
            if row[2] is None:
                continue
            result.append({
                'movieid':         row[0],
                'idFile':          row[1],
                'tmdb_id':         str(row[2]),
                'title':           row[3],
                'playcount':       row[4],
                'lastplayed':      row[5],
                'resume_position': row[6],
                'resume_total':    row[7],
                'player_state':    row[8],
            })
        return result
    except Exception:
        log(f'Error fetching movies:\n{traceback.format_exc()}', xbmc.LOGERROR)
        return None


def get_all_played_episodes():
    """
    查询所有有播放记录或续播进度的剧集。
    返回列表，每条记录：{episodeid, idFile, key(show_tmdb_S??E??), showtitle,
                          season, episode, playcount, lastplayed,
                          resume_position, resume_total, player_state}
    """
    conn = _get_conn()
    if not conn:
        return None
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.idEpisode,
                   e.idFile,
                   uid_s.value AS show_tmdb_id,
                   e.c12 AS season,
                   e.c13 AS episode_num,
                   s.c00 AS showtitle,
                   f.playCount,
                   f.lastPlayed,
                   b.timeInSeconds AS resume_position,
                   b.totalTimeInSeconds AS resume_total,
                   b.playerState AS player_state
            FROM episode e
            JOIN tvshow s ON s.idShow = e.idShow
            JOIN files f ON f.idFile = e.idFile
            JOIN uniqueid uid_s ON uid_s.media_id = e.idShow
                                AND uid_s.media_type = 'tvshow'
                                AND uid_s.type = 'tmdb'
            LEFT JOIN bookmark b ON b.idFile = e.idFile AND b.type = 1
            WHERE f.playCount > 0
               OR (f.lastPlayed IS NOT NULL AND f.lastPlayed != '')
               OR b.idBookmark IS NOT NULL
        """)
        rows = cursor.fetchall()
        cursor.close()
        result = []
        for row in rows:
            if row[2] is None or row[3] is None or row[4] is None:
                continue
            try:
                season = int(row[3])
                ep_num = int(row[4])
            except (ValueError, TypeError):
                continue
            show_tmdb = str(row[2])
            key = f'{show_tmdb}_S{season:02d}E{ep_num:02d}'
            result.append({
                'episodeid':       row[0],
                'idFile':          row[1],
                'key':             key,
                'showtitle':       row[5],
                'season':          season,
                'episode':         ep_num,
                'playcount':       row[6],
                'lastplayed':      row[7],
                'resume_position': row[8],
                'resume_total':    row[9],
                'player_state':    row[10],
            })
        return result
    except Exception:
        log(f'Error fetching episodes:\n{traceback.format_exc()}', xbmc.LOGERROR)
        return None


def update_file_record(idFile, playcount, lastplayed, resume_position, resume_total, player_state):
    """
    直接更新数据库中的播放记录：
      - files.playCount / files.lastPlayed
      - bookmark (type=1) 续播进度及 playerState
        · resume_position > 0：upsert resume bookmark
        · resume_position = 0：删除 resume bookmark
    """
    conn = _get_conn()
    if not conn:
        return False
    ph = '%s' if _is_mysql else '?'
    cursor = None
    try:
        cursor = conn.cursor()

        if _is_mysql:
            cursor.execute('START TRANSACTION')

        cursor.execute(
                f'UPDATE files SET playCount={ph}, lastPlayed={ph} WHERE idFile={ph}',
                (playcount, lastplayed, idFile),
            )


        if resume_position and resume_position > 0:
            # 查询是否已有 resume bookmark
            cursor.execute(
                f'SELECT idBookmark FROM bookmark WHERE idFile={ph} AND type=1',
                (idFile,),
            )
            row = cursor.fetchone()
            if row:
                cursor.execute(
                    f'UPDATE bookmark '
                    f'SET timeInSeconds={ph}, totalTimeInSeconds={ph}, playerState={ph} '
                    f'WHERE idBookmark={ph}',
                    (resume_position, resume_total or 0.0, player_state or '', row[0]),
                )
            else:
                cursor.execute(
                    f'INSERT INTO bookmark '
                    f'(idFile, timeInSeconds, totalTimeInSeconds, thumbNailImage, player, playerState, type) '
                    f'VALUES ({ph},{ph},{ph},{ph},{ph},{ph},1)',
                    (idFile, resume_position, resume_total or 0.0, '', 'VideoPlayer', player_state or ''),
                )
        else:
            # 续播进度为 0，删除 resume bookmark
            cursor.execute(
                f'DELETE FROM bookmark WHERE idFile={ph} AND type=1',
                (idFile,),
            )

        conn.commit()
        log(f'Updated file record: idFile={idFile} playcount={playcount}')
        return True
    except Exception:
        try:
            conn.rollback()
        except Exception:
            log(f'Error rolling back file record update idFile={idFile}:\n{traceback.format_exc()}',
                xbmc.LOGERROR)
        log(f'Error updating file record idFile={idFile}:\n{traceback.format_exc()}',
            xbmc.LOGERROR)
        return False
    finally:
        if cursor is not None:
            cursor.close()


# ---------------------------------------------------------------------------
# 全库 ID 查询（不限制播放状态，用于 shadow 比对）
# ---------------------------------------------------------------------------

def get_all_movie_ids():
    """
    返回库中所有电影的 {tmdb_id_str: idFile} 映射，不限制是否有播放记录。
    用于 shadow 比对时区分"手动标记未观看"和"重置电影库"。
    """
    conn = _get_conn()
    if not conn:
        return None
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT uid.value AS tmdb_id, m.idFile
            FROM movie m
            JOIN uniqueid uid ON uid.media_id = m.idMovie
                              AND uid.media_type = 'movie'
                              AND uid.type = 'tmdb'
        """)
        rows = cursor.fetchall()
        cursor.close()
        return {str(row[0]): row[1] for row in rows}
    except Exception:
        log(f'Error fetching all movie ids:\n{traceback.format_exc()}', xbmc.LOGERROR)
        return None


def get_all_episode_ids():
    """
    返回库中所有剧集的 {key: idFile} 映射，key 格式同 get_all_episodes()。
    不限制是否有播放记录，用于 shadow 比对。
    """
    conn = _get_conn()
    if not conn:
        return {}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT uid_s.value AS show_tmdb_id, e.c12 AS season, e.c13 AS episode_num, e.idFile
            FROM episode e
            JOIN uniqueid uid_s ON uid_s.media_id = e.idShow
                                AND uid_s.media_type = 'tvshow'
                                AND uid_s.type = 'tmdb'
        """)
        rows = cursor.fetchall()
        cursor.close()
        result = {}
        for row in rows:
            if row[0] is None or row[1] is None or row[2] is None:
                continue
            try:
                season = int(row[1])
                ep_num = int(row[2])
            except (ValueError, TypeError):
                continue
            key = f'{row[0]}_S{season:02d}E{ep_num:02d}'
            result[key] = row[3]
        return result
    except Exception:
        log(f'Error fetching all episode ids:\n{traceback.format_exc()}', xbmc.LOGERROR)
        return None


# ---------------------------------------------------------------------------
# 生命周期
# ---------------------------------------------------------------------------

def close():
    """关闭数据库连接。"""
    global _conn, _is_mysql
    if _conn is not None:
        try:
            _conn.close()
        except Exception:
            pass
        _conn = None
        _is_mysql = False
