# -*- coding: utf-8 -*-
"""
核心同步逻辑：
  - sync                    : 全量双向合并（Kodi ↔ JSON 文件），一次完成
  - check_and_sync_if_changed: 检查文件 mtime，变化则 sync

合并规则（统一）：
    - playcount        归属 lastplayed 更新的那一方
  - lastplayed       取最新时间
  - resume_position  归属 lastplayed 更新的那一方
"""

import os
import json
import time
import threading
import traceback

import xbmc
import xbmcgui
import xbmcvfs

from lib.common import log, get_setting, notification, trigger_fake_video_library_scan
from lib import db as _db

FILE_FORMAT_VERSION = 1
# 设备本地字段，不写入同步 JSON 文件
_LOCAL_FIELDS = frozenset({'movieid', 'episodeid', 'idFile', 'file_path'})
TRACK_FILENAME = 'watch_track.json'


# ---------------------------------------------------------------------------
# 日期时间工具
# ---------------------------------------------------------------------------

def _parse_dt(dt_str):
    """将 Kodi 格式日期字符串解析为可比较的时间对象，失败返回 None。"""
    if not dt_str:
        return None
    try:
        text = dt_str.strip() if isinstance(dt_str, str) else dt_str
        return time.strptime(text, '%Y-%m-%d %H:%M:%S')
    except Exception:
        log(f'Error parsing datetime "{dt_str}":\n{traceback.format_exc()}', xbmc.LOGWARNING)
        return None


def _max_dt_str(a, b):
    """返回两个日期字符串中较新的那个。"""
    da, db = _parse_dt(a), _parse_dt(b)
    if da is None:
        return b 
    if db is None:
        return a 
    return a if da >= db else b


# ---------------------------------------------------------------------------
# 记录合并
# ---------------------------------------------------------------------------

def _merge_record(local, remote):
    """
    合并本地（Kodi）和远端（文件）的单条记录。
    - playcount  : 归属于 lastplayed 更新的那一方
    - lastplayed : 取最新时间
    - resume     : 归属于 lastplayed 更新的那一方
    返回合并后的 dict（包含双方所有 metadata 字段）。
    """
    local_pc = local.get('playcount')
    remote_pc = remote.get('playcount')

    local_lp = local.get('lastplayed')
    remote_lp = remote.get('lastplayed')

    merged_lp = _max_dt_str(local_lp, remote_lp)

    # playcount / resume / player_state 跟随 lastplayed 较新的那方
    da, db = _parse_dt(local_lp), _parse_dt(remote_lp)
    remote_is_newer = db is not None and (da is None or db > da)
    parsed_same_timestamp = da is not None and db is not None and da == db
    raw_same_timestamp = bool(local_lp) and bool(remote_lp) and local_lp == remote_lp
    same_timestamp = parsed_same_timestamp or raw_same_timestamp
    local_pos = local.get('resume_position')
    remote_pos = remote.get('resume_position')
    local_total = local.get('resume_total')
    remote_total = remote.get('resume_total')
    local_player_state = local.get('player_state')
    remote_player_state = remote.get('player_state')
    if remote_is_newer:
        merged_pc = remote_pc
        merged_pos = remote_pos
        merged_total = remote_total
    elif same_timestamp:
        merged_pc = local_pc if local_pc is not None else remote_pc
        merged_pos = local_pos if local_pos is not None else remote_pos
        merged_total = local_total if local_total is not None else remote_total
    else:
        if da is None:
            merged_pc = None
            merged_pos = None
            merged_total = None
        else:
            merged_pc = local_pc
            merged_pos = local_pos
            merged_total = local_total

    # player_state 与 resume 同侧；本地没有 lastplayed 时也不认本地 player_state
    if remote_is_newer:
        merged_player_state = remote_player_state
    elif same_timestamp:
        if local_player_state not in (None, ''):
            merged_player_state = local_player_state
        else:
            merged_player_state = remote_player_state
    else:
        merged_player_state = None if da is None else local_player_state

    result = {}
    result.update(remote)   # 先用远端数据（带 title 等 metadata）
    result.update(local)    # 再覆盖为本地数据（以本地 metadata 为准）
    result['playcount'] = merged_pc
    result['lastplayed'] = merged_lp
    result['resume_position'] = merged_pos
    result['resume_total'] = merged_total
    result['player_state'] = merged_player_state
    return result





# ---------------------------------------------------------------------------
# SyncManager
# ---------------------------------------------------------------------------

class SyncManager:
    def __init__(self):
        self.file_path = ''
        self.sync_on_stop = True
        self.check_interval = 60
        self._lock = threading.RLock()
        self._closed = False
        # 上次已知的文件 mtime，用于判断是否被外部修改
        self._last_known_mtime = 0.0
        self.reload_settings()
        
        
        self._shadow_dir = 'special://userdata/addon_data/service.watch.track/'
        if not xbmcvfs.exists(self._shadow_dir):
            xbmcvfs.mkdirs(self._shadow_dir)
        self._shadow_path = self._shadow_dir + 'shadow.json'

    # ------------------------------------------------------------------
    # 配置
    # ------------------------------------------------------------------

    def reload_settings(self):
        with self._lock:
            if self._closed:
                return False, self.file_path, self.file_path

            old_file_path = self.file_path
            self.file_path = get_setting('track_file') or ''
            self.sync_on_stop = (get_setting('sync_on_stop') or 'true').lower() == 'true'
            try:
                self.check_interval = int(float(get_setting('check_interval') or '60'))
            except Exception:
                log(f'Error parsing check_interval:\n{traceback.format_exc()}', xbmc.LOGWARNING)
                self.check_interval = 60
            log(f'Settings reloaded: file="{self.file_path}" sync_on_stop={self.sync_on_stop} interval={self.check_interval}s')
            return self.file_path != old_file_path, old_file_path, self.file_path

    def close(self):
        with self._lock:
            if self._closed:
                return

            self._closed = True
            _db.close()

    def _get_sync_file_mtime(self, log_details=False):
        stat_obj = xbmcvfs.Stat(self.file_path)
        atime = float(stat_obj.st_atime())
        mtime = float(stat_obj.st_mtime())
        ctime = float(stat_obj.st_ctime())
        size = int(stat_obj.st_size())

        if log_details or mtime <= 0.0:
            log(
                f'Sync file stat raw: atime={atime:.1f}, mtime={mtime:.1f}, '
                f'ctime={ctime:.1f}, size={size}, path: {self.file_path}'
            )

        return mtime

    def _load_shadow(self):
        if not xbmcvfs.exists(self._shadow_path):
            return {'track_file': self.file_path, 'movies': {}, 'episodes': {}}
        try:
            with xbmcvfs.File(self._shadow_path) as f:
                data = json.loads(f.read())
            shadow_track_file = data.get('track_file') or ''
            current_track_file = self.file_path or ''
            if shadow_track_file != current_track_file:
                log(f'Shadow track file changed: shadow="{shadow_track_file}" current="{current_track_file}", resetting shadow state.')
                return {'track_file': self.file_path, 'movies': {}, 'episodes': {}}
            if not isinstance(data.get('movies'), dict):
                data['movies'] = {}
            if not isinstance(data.get('episodes'), dict):
                data['episodes'] = {}
            data['track_file'] = self.file_path
            return data
        except Exception:
            log(f'Error loading shadow file:\n{traceback.format_exc()}', xbmc.LOGWARNING)
            return None

    def _write_shadow(self, data):
        try:
            f = xbmcvfs.File(self._shadow_path, 'w')
            f.write(json.dumps(data, ensure_ascii=False))
            f.close()
            return True
        except Exception:
            log(f'Error writing shadow file:\n{traceback.format_exc()}', xbmc.LOGERROR)
            return False

    def clear_shadow(self):
        try:
            if not xbmcvfs.exists(self._shadow_path):
                return True
            if xbmcvfs.delete(self._shadow_path):
                log('Shadow invalidated by deleting local shadow file.', xbmc.LOGWARNING)
                return True
            log('Failed to delete shadow file, writing invalid shadow marker instead.', xbmc.LOGWARNING)
        except Exception:
            log(f'Error deleting shadow file:\n{traceback.format_exc()}', xbmc.LOGWARNING)

        invalid_shadow = {
            'track_file': '__invalid__',
            'movies': {},
            'episodes': {},
        }
        if self._write_shadow(invalid_shadow):
            log('Shadow invalidated by writing invalid marker.', xbmc.LOGWARNING)
            return True
        log('Failed to invalidate shadow file.', xbmc.LOGERROR)
        return False

    # ------------------------------------------------------------------
    # trace file 文件 I/O
    # ------------------------------------------------------------------

    def _load_trace_file(self):
        if not self.file_path:
            log('No sync file configured.', xbmc.LOGWARNING)
            return None
        if not xbmcvfs.exists(self.file_path):
            log(f'Sync file missing or inaccessible: {self.file_path}', xbmc.LOGERROR)
            notification('同步文件不存在或不可访问', icon=xbmcgui.NOTIFICATION_ERROR)
            return None
        raw_text = ''
        try:
            with xbmcvfs.File(self.file_path) as f:
                raw_text = f.read()
                data = json.loads(raw_text)
            if not isinstance(data.get('movies'), dict):
                data['movies'] = {}
            if not isinstance(data.get('episodes'), dict):
                data['episodes'] = {}
            return data
        except Exception as e:
            if raw_text:
                log(f'Read sync file raw content ({len(raw_text)} chars):\n{raw_text}', xbmc.LOGERROR)
            else:
                log('Read sync file raw content is empty.', xbmc.LOGERROR)
            log(f'Error loading JSON file: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
            notification(f'读取同步文件失败: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
            return None

    def _save_trace_file(self, data):
        if not self.file_path:
            return False
        try:
            dir_path = os.path.dirname(self.file_path)
            if dir_path and not xbmcvfs.exists(dir_path):
                xbmcvfs.mkdirs(dir_path)

            # 原子写入：先写临时文件再 rename
            tmp_path = self.file_path + '.tmp'
            try:
                f = xbmcvfs.File(tmp_path, 'w')
                f.write(json.dumps(data, ensure_ascii=False, indent=2))
                f.close()
                if not xbmcvfs.rename(tmp_path, self.file_path):
                    # rename 不被某些 VFS 协议支持（如 WebDAV），回退到 copy + delete
                    if xbmcvfs.copy(tmp_path, self.file_path):
                        xbmcvfs.delete(tmp_path)
                    else:
                        notification('写入同步文件失败（无法重命名或复制）', icon=xbmcgui.NOTIFICATION_ERROR)
                        raise IOError('Failed to write sync file (both rename and copy failed)')
            except Exception as e:
                try:
                    notification(f'写入同步文件失败: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
                    xbmcvfs.delete(tmp_path)
                except Exception:
                    pass
                raise

            # 记录本次写入的 mtime，避免下次轮询误判为外部变更
            self._last_known_mtime = self._get_sync_file_mtime()
            return True
        except Exception as e:
            log(f'Error writing JSON file: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
            notification(f'写入同步文件失败: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
            return False

    # ------------------------------------------------------------------
    # 查询 Kodi 库
    # ------------------------------------------------------------------

    def _get_played_kodi_movies(self):
        """返回 {tmdb_id_str: record}，record 包含 movieid, idFile, title, playcount, lastplayed,
        resume_position, resume_total, player_state。"""
        data = _db.get_all_played_movies()
        if data is None:
            return None
        movies = {}
        for row in data:
            movies[row['tmdb_id']] = row
        return movies

    def _get_played_kodi_episodes(self):
        """返回 {key: record}，key 格式为 '{show_tmdb}_S{season:02d}E{ep:02d}'，
        record 包含 episodeid, idFile, showtitle, season, episode, playcount, lastplayed,
        resume_position, resume_total, player_state。"""
        data = _db.get_all_played_episodes()
        if data is None:
            return None
        episodes = {}
        for row in data:
            episodes[row['key']] = row
        return episodes

    # ------------------------------------------------------------------
    # 写回 Kodi 库
    # ------------------------------------------------------------------

    def _update_kodi_movie(self, idFile, data):
        status = _db.update_file_record(
            idFile,
            data.get('playcount'),
            data.get('lastplayed'),
            data.get('resume_position'),
            data.get('resume_total'),
            data.get('player_state'),
        )
        if not status:
            log(f'Failed to update Kodi movie record for idFile={idFile}', xbmc.LOGERROR)
            notification('更新 Kodi 电影记录失败', icon=xbmcgui.NOTIFICATION_ERROR)
        return status

    def _update_kodi_episode(self, idFile, data):
        status = _db.update_file_record(
            idFile,
            data.get('playcount'),
            data.get('lastplayed'),
            data.get('resume_position'),
            data.get('resume_total'),
            data.get('player_state'),
        )
        if not status:
            log(f'Failed to update Kodi episode record for idFile={idFile}', xbmc.LOGERROR)
            notification('更新 Kodi 剧集记录失败', icon=xbmcgui.NOTIFICATION_ERROR)
        return status

    # ------------------------------------------------------------------
    # 对外接口
    # ------------------------------------------------------------------

    def sync(self):
        """
        全量双向合并：
          1. 读取 Kodi watched 记录
          2. 读取 shadow（上次同步时的 watched idFile 快照）
          3. 读取共享 JSON
          4. 按需懒加载全库 id 映射：仅当 shadow 中存在 watched 没有的条目时才扫全库
          5. 通过比对 shadow 检测"手动标记未观看"：
             - shadow 中有、watched 中没有、该条目 idFile 不变 → 手动标记未观看 → 删除 JSON 中对应记录
             - shadow 中有、watched 中没有、该条目 idFile 已变 → 库被重置 → 保留 JSON，后续写回 Kodi
          6. 对所有条目执行合并（playcount / resume 跟最新方，lastplayed 取最新）：
             - kodi 有 & JSON 有 → merge 后写回差异项
             - kodi 有 & JSON 没有 & shadow 有 → 其他设备删除了该记录（标记未观看）→ 本机也清除，不写 JSON
             - kodi 有 & JSON 没有 & shadow 也没有 → 本机新增记录 → 写入 JSON
             - kodi 没有 & JSON 有 & 全库有该 id → 库重置 → 用新 idFile 写回 Kodi
          8. 将合并结果写回 JSON 文件
          9. 将合并结果中与 Kodi 当前值不同的条目写回 Kodi 库
          10. 保存新 shadow（本次 watched 的 idFile 快照）
        """
        with self._lock:
            if self._closed:
                log('sync: manager already closed, skipping.')
                return False
            if not self.file_path:
                log('sync: no file path configured, skipping.')
                return False

            log('Syncing watch data...')

            # Step 1: 读取 Kodi watched 记录
            kodi_movies = self._get_played_kodi_movies()       # {tmdb_id: full_record}，仅观看过
            kodi_episodes = self._get_played_kodi_episodes()   # {key: full_record}，仅观看过
            if kodi_movies is None or kodi_episodes is None:
                log('sync aborted: failed to load Kodi data.', xbmc.LOGERROR)
                return False

            # Step 2: 读取 shadow
            shadow = self._load_shadow()
            if shadow is None:
                log('sync aborted: failed to load shadow.', xbmc.LOGERROR)
                return False
            shadow_movies = shadow.get('movies', {})
            shadow_episodes = shadow.get('episodes', {})

            # Step 3: 读取 JSON。读取失败视为异常故障，直接终止同步，避免误删本地记录。
            try:
                trace_file_mtime = self._get_sync_file_mtime()
            except Exception:
                log(f'Error reading sync file mtime before sync:\n{traceback.format_exc()}', xbmc.LOGWARNING)
                trace_file_mtime = 0.0

            trace_data = self._load_trace_file()
            if trace_data is None:
                log('sync aborted: failed to load sync file.', xbmc.LOGWARNING)
                return False

            track_file_update_count = 0
            if trace_data.get('version') != FILE_FORMAT_VERSION:
                track_file_update_count += 1
            if any(key not in ('version', 'movies', 'episodes') for key in trace_data):
                track_file_update_count += 1

            # Step 4: 判断是否需要全库扫描
            # 触发条件1：shadow 中有、watched 中没有 → 需要比对 idFile 区分"手动标记未观看"和"库重置"
            # 触发条件2：JSON 中有、watched 中没有 → 需要确认该电影是否在本机库中（库重置后写回 Kodi）
            #            若不扫全库，kodi_all_movies 为空，会误判为"其他设备的记录"而跳过写回
            shadow_missing_movies = {tid for tid in shadow_movies if tid not in kodi_movies}
            shadow_missing_episodes = {k for k in shadow_episodes if k not in kodi_episodes}
            trace_only_movies = {tid for tid in trace_data.get('movies', {}) if tid not in kodi_movies}
            trace_only_episodes = {k for k in trace_data.get('episodes', {}) if k not in kodi_episodes}

            kodi_all_movies = {}
            kodi_all_episodes = {}
            if shadow_missing_movies or trace_only_movies:
                kodi_all_movies = _db.get_all_movie_ids()
                if kodi_all_movies is None:
                    log('sync aborted: failed to load all Kodi movie ids.', xbmc.LOGERROR)
                    return False
            if shadow_missing_episodes or trace_only_episodes:
                kodi_all_episodes = _db.get_all_episode_ids()
                if kodi_all_episodes is None:
                    log('sync aborted: failed to load all Kodi episode ids.', xbmc.LOGERROR)
                    return False

            # Step 5: 检测手动标记未观看的电影
            for tmdb_id in shadow_missing_movies:
                shadow_id_file = shadow_movies[tmdb_id]
                current_id_file = kodi_all_movies.get(tmdb_id)
                if current_id_file is not None and current_id_file == shadow_id_file:
                    # 该电影的 idFile 没变 → 手动标记未观看 → 从 JSON 删除
                    removed_movie = trace_data.get('movies', {}).pop(tmdb_id, None)
                    if removed_movie is not None:
                        track_file_update_count += 1
                    log(f'  Movie {tmdb_id} manually marked unwatched, removed from JSON '
                        f'(shadow_idFile={shadow_id_file} current_idFile={current_id_file})')
                # 该电影的 idFile 变了 → 库重置，保留 JSON，后续 merge 写回 Kodi
                # 全库中找不到该电影 → 从库移除，不动 JSON

            # Step 6: 检测手动标记未观看的剧集
            for key in shadow_missing_episodes:
                shadow_id_file = shadow_episodes[key]
                current_id_file = kodi_all_episodes.get(key)
                if current_id_file is not None and current_id_file == shadow_id_file:
                    removed_episode = trace_data.get('episodes', {}).pop(key, None)
                    if removed_episode is not None:
                        track_file_update_count += 1
                    log(f'  Episode {key} manually marked unwatched, removed from JSON')

            merged_movies = {}
            merged_episodes = {}
            movie_updates = []    # [(idFile, merged_rec), ...]
            episode_updates = []  # [(idFile, merged_rec), ...]

            # ---- 电影 ----
            all_movie_keys = set(kodi_movies.keys()) | set(trace_data.get('movies', {}).keys())
            for tmdb_id in all_movie_keys:
                kodi = kodi_movies.get(tmdb_id)
                file_rec = trace_data.get('movies', {}).get(tmdb_id)

                if kodi and file_rec:
                    m = _merge_record(kodi, file_rec)
                    if (m['playcount'] != kodi['playcount']
                            or m['lastplayed'] != kodi['lastplayed']
                            or m['resume_position'] != kodi['resume_position']
                            or m['player_state'] != kodi['player_state']):
                        movie_updates.append((kodi['idFile'], m))
                        log(f'  Movie {tmdb_id} "{kodi["title"]}" needs update')
                    merged_movie = {k: v for k, v in m.items() if k not in _LOCAL_FIELDS}
                    if merged_movie != file_rec:
                        track_file_update_count += 1
                    merged_movies[tmdb_id] = merged_movie
                elif kodi:
                    if tmdb_id in shadow_movies:
                        # tracefile 没有但 shadow 有 → 其他设备删除了该记录（标记为未观看）→ 本机也清除
                        movie_updates.append((kodi['idFile'], {'playcount': None, 'lastplayed': None,
                                                               'resume_position': 0.0, 'resume_total': 0.0,
                                                               'player_state': ''}))
                        log(f'  Movie {tmdb_id} "{kodi["title"]}" unmarked by another device, clearing local')
                        # 不写入 merged_movies，记录从 tracefile 移除
                    else:
                        # shadow 也没有 → 本机新增记录，仅当有 lastplayed 时写入 tracefile
                        if kodi.get('lastplayed'):
                            merged_movies[tmdb_id] = {k: v for k, v in kodi.items() if k not in _LOCAL_FIELDS}
                            track_file_update_count += 1
                            log(f'  Movie {tmdb_id} "{kodi["title"]}" only exists locally, keeping it in JSON')
                        else:
                            log(f'  Movie {tmdb_id} "{kodi["title"]}" only exists locally but has no lastplayed, skipping JSON write')
                else:
                    # 仅存在于 tracefile：检查是否库被重置（全库有该 id）
                    new_id_file = kodi_all_movies.get(tmdb_id)
                    if new_id_file is not None:
                        # 库重置后该电影仍在库中，用新 idFile 写回 Kodi
                        movie_updates.append((new_id_file, file_rec))
                        log(f'  Movie {tmdb_id} library reset, restoring to Kodi (idFile={new_id_file})')
                    merged_movies[tmdb_id] = file_rec

            # ---- 剧集 ----
            all_ep_keys = set(kodi_episodes.keys()) | set(trace_data.get('episodes', {}).keys())
            for key in all_ep_keys:
                kodi = kodi_episodes.get(key)
                file_rec = trace_data.get('episodes', {}).get(key)

                if kodi and file_rec:
                    m = _merge_record(kodi, file_rec)
                    if (m['playcount'] != kodi['playcount']
                            or m['lastplayed'] != kodi['lastplayed']
                            or m['resume_position'] != kodi['resume_position']
                            or m['player_state'] != kodi['player_state']):
                        episode_updates.append((kodi['idFile'], m))
                        log(f'  Episode {key} "{kodi["showtitle"]}" needs update')
                    merged_episode = {k: v for k, v in m.items() if k not in _LOCAL_FIELDS}
                    if merged_episode != file_rec:
                        track_file_update_count += 1
                    merged_episodes[key] = merged_episode
                elif kodi:
                    if key in shadow_episodes:
                        # JSON 没有但 shadow 有 → 其他设备删除了该记录（标记为未观看）→ 本机也清除
                        episode_updates.append((kodi['idFile'], {'playcount': None, 'lastplayed': None,
                                                                 'resume_position': 0.0, 'resume_total': 0.0,
                                                                 'player_state': ''}))
                        log(f'  Episode {key} "{kodi["showtitle"]}" unmarked by another device, clearing local')
                        # 不写入 merged_episodes，记录从 JSON 移除
                    else:
                        # shadow 也没有 → 本机新增记录，仅当有 lastplayed 时写入 JSON
                        if kodi.get('lastplayed'):
                            merged_episodes[key] = {k: v for k, v in kodi.items() if k not in _LOCAL_FIELDS}
                            track_file_update_count += 1
                else:
                    new_id_file = kodi_all_episodes.get(key)
                    if new_id_file is not None:
                        episode_updates.append((new_id_file, file_rec))
                        log(f'  Episode {key} library reset, restoring to Kodi (idFile={new_id_file})')
                    merged_episodes[key] = file_rec

            # ---- 写回文件 ----
            new_file_data = {
                'version': FILE_FORMAT_VERSION,
                'movies': merged_movies,
                'episodes': merged_episodes,
            }
            if track_file_update_count > 0:
                log(f'Sync file requires update, track_file_update_count={track_file_update_count}')
                if not self._save_trace_file(new_file_data):
                    log('sync aborted: failed to write sync file, skip local updates.', xbmc.LOGERROR)
                    return False
            else:
                self._last_known_mtime = trace_file_mtime
                log('Sync file content unchanged, skipped rewriting JSON.')

            # ---- 写回 Kodi ----
            kodi_db_updated = False
            kodi_write_failed = False
            for idFile, rec in movie_updates:
                if self._update_kodi_movie(idFile, rec):
                    kodi_db_updated = True
                else:
                    kodi_write_failed = True
            for idFile, rec in episode_updates:
                if self._update_kodi_episode(idFile, rec):
                    kodi_db_updated = True
                else:
                    kodi_write_failed = True

            if kodi_db_updated:
                trigger_fake_video_library_scan()

            # ---- 保存或作废 shadow ----
            if kodi_write_failed:
                self.clear_shadow()
            else:
                shadow_movies_snapshot = kodi_movies
                shadow_episodes_snapshot = kodi_episodes
                if movie_updates or episode_updates:
                    shadow_movies_snapshot = self._get_played_kodi_movies()
                    shadow_episodes_snapshot = self._get_played_kodi_episodes()
                    if shadow_movies_snapshot is None or shadow_episodes_snapshot is None:
                        log('Failed to reload Kodi data after local updates, invalidating shadow.', xbmc.LOGERROR)
                        self.clear_shadow()
                        return False

                self._write_shadow({
                    'track_file': self.file_path,
                    'movies': {tid: rec['idFile'] for tid, rec in shadow_movies_snapshot.items()},
                    'episodes': {k: rec['idFile'] for k, rec in shadow_episodes_snapshot.items()},
                })

            log(f'Sync complete. '
                f'movies={len(merged_movies)} episodes={len(merged_episodes)} '
                f'kodi_updates={len(movie_updates) + len(episode_updates)}')
            
            
            
            if kodi_write_failed:
                log('Some Kodi records failed to update, shadow has been invalidated. Please check the logs for details.', xbmc.LOGERROR)
                return False
            return True
    


    def check_and_sync_if_changed(self):
        """检查文件 mtime，若被外部修改则执行 sync。返回是否触发了同步。"""
        log('Checking sync file for external changes...')
        if not self._lock.acquire(blocking=False):
            log('Periodic sync skipped: sync lock is busy.', xbmc.LOGWARNING)
            return False

        try:
            if self._closed or not self.file_path:
                log('Periodic sync skipped: manager closed or no sync file.', xbmc.LOGWARNING)
                return False
            try:
                mtime = self._get_sync_file_mtime(log_details=True)
                if mtime <= 0.0:
                    log(f'Periodic sync skipped: sync file missing or mtime unavailable, path: {self.file_path}', xbmc.LOGWARNING)
                    return False
                log(f'Current sync file effective mtime: {mtime:.1f}, last known mtime: {self._last_known_mtime:.1f}, path: {self.file_path}')
                if mtime > self._last_known_mtime + 0.5:   # 0.5s 容差，避免浮点误差
                    log(f'File changed (mtime {mtime:.1f} > {self._last_known_mtime:.1f}), syncing...')
                    ret = self.sync()
                    return ret
            except Exception as e:
                log(f'Error checking file mtime: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
            return False
        finally:
            self._lock.release()
