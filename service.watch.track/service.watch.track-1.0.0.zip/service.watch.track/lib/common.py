# -*- coding: utf-8 -*-
import json
import traceback
import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = 'service.watch.track'
ADDON_NAME = 'Watch Track'
FAKE_VIDEO_SCAN_DIRECTORY = 'WATCHTRACK_widget_refresh_trigger'


def get_addon():
    return xbmcaddon.Addon(ADDON_ID)


def get_setting(key):
    return get_addon().getSetting(key)


def set_setting(key, value):
    get_addon().setSetting(key, str(value))


def addon_string(str_id):
    return get_addon().getLocalizedString(str_id)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[WatchTrack] {msg}', level)


def addon_icon():
    return get_addon().getAddonInfo('icon')


def notification(msg, title=ADDON_NAME, icon=None, time_ms=4000):
    if icon is None:
        icon = addon_icon()
    xbmcgui.Dialog().notification(title, msg, icon, time_ms)


def jsonrpc_request(payload):
    """执行 JSON-RPC 请求，返回 result 字段，失败返回 None。"""
    try:
        text = xbmc.executeJSONRPC(json.dumps(payload))
        resp = json.loads(text)
        if isinstance(resp, dict) and 'error' in resp:
            method = payload.get('method', 'unknown') if isinstance(payload, dict) else 'unknown'
            log(f'JSON-RPC error [{method}]: {resp["error"]}', xbmc.LOGWARNING)
            return None
        return resp.get('result') if isinstance(payload, dict) else resp
    except Exception as e:
        log(f'JSON-RPC exception: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
        return None


def trigger_fake_video_library_scan():
    """触发一次假的 VideoLibrary.Scan，促使 Kodi 刷新视频库 UI。"""
    result = jsonrpc_request({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'VideoLibrary.Scan',
        'params': {
            'showdialogs': False,
            'directory': FAKE_VIDEO_SCAN_DIRECTORY,
        },
    })
    if result is None:
        log('Fake VideoLibrary.Scan failed.', xbmc.LOGWARNING)
        return False
    log('Triggered fake VideoLibrary.Scan for playback progress refresh.')
    return True
