# Watch Track

Watch Track 是一个 Kodi 后台服务插件，通过读写网盘上的JSON文件在多台 Kodi 设备之间同步播放记录。

它会同步以下信息：

- 已观看次数
- 最后播放时间
- 续播进度
- 播放状态

电影使用 TMDB ID 作为标识，剧集使用 TMDB ID + SXXEXX 作为标识。

## 工作方式

插件启动后会在后台运行，并在以下时机触发同步：

- Kodi 启动完成后的首次延迟同步
- 播放停止或播放结束后同步
- 检测到同步文件被外部修改后同步
- 设置中的同步文件路径发生变化后同步

## 使用方法

1. 安装插件，手动下载安装，或者通过仓库安装 [repository.forbxy](https://github.com/forbxy/repository.forbxy)。
2. 打开插件设置，配置同步文件路径。
3. 可以通过设置页按钮：
	 - 选择已有的 `.json` 文件
	 - 在指定目录中自动创建 `watch_track.json`
4. 在所有需要同步的 Kodi 设备上，将同步文件指向同一个共享 JSON 文件。

## 设置项

- `sync_on_stop`：播放停止或结束后是否立即同步，默认开启
- `check_interval`：轮询同步文件修改时间的间隔，默认 60 秒

## 同步文件

首次创建的同步文件格式如下：

```json
{
	"version": 1,
	"movies": {},
	"episodes": {}
}
```

## 开发

- 开发部署：运行 `dev/dev_deploy.py`
- 打包发布：运行 `dev/build_package.py`

打包输出文件位于 `dist/service.watch.track-<version>.zip`。
