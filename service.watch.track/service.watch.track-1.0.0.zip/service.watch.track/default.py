# -*- coding: utf-8 -*-
"""
脚本入口，供设置页面的 action 按钮调用：
  RunScript(special://home/addons/service.watch.track/default.py,select_file)

弹出对话框让用户：
  1. 选择已有 .json 文件作为跟踪文件
  2. 选择一个目录并在其中自动创建 watch_track.json
"""
import sys
import json
import traceback

import xbmc
import xbmcgui
import xbmcvfs

from lib.common import log, get_addon

TRACK_FILENAME = 'watch_track.json'


def select_file():
    addon = get_addon()
    dialog = xbmcgui.Dialog()

    current = addon.getSetting('track_file') or ''
    start_dir = current.rsplit('/', 1)[0] if '/' in current else current.rsplit('\\', 1)[0] if '\\' in current else ''

    choices = [
        addon.getLocalizedString(32004),   # 选择已有文件
        addon.getLocalizedString(32005),   # 创建新跟踪文件
    ]
    idx = dialog.select(addon.getLocalizedString(32003), choices)

    if idx == 0:
        # ---- 选择已有文件 ----
        path = dialog.browse(1, addon.getLocalizedString(32004),
                             'files', '.json', False, False, start_dir)
        if path and xbmcvfs.exists(path):
            addon.setSetting('track_file', path)

    elif idx == 1:
        # ---- 在指定目录创建新文件 ----
        folder = dialog.browse(0, addon.getLocalizedString(32007),
                               'files', '', False, False, start_dir)
        if not folder:
            return

        folder = folder.rstrip('/\\')
        file_path = folder + '/' + TRACK_FILENAME

        try:
            if not xbmcvfs.exists(file_path):
                initial_data = {'version': 1, 'movies': {}, 'episodes': {}}
                f = xbmcvfs.File(file_path, 'w')
                f.write(json.dumps(initial_data, ensure_ascii=False, indent=2))
                f.close()
            addon.setSetting('track_file', file_path)
            dialog.notification(
                addon.getAddonInfo('name'),
                f'{addon.getLocalizedString(32008)}: {file_path}',
                xbmcgui.NOTIFICATION_INFO, 5000,
            )
        except Exception as e:
            log(f'Failed to create tracking file: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
            dialog.notification(
                addon.getAddonInfo('name'),
                addon.getLocalizedString(32009),
                xbmcgui.NOTIFICATION_ERROR, 5000,
            )


if __name__ == '__main__':
    args = sys.argv[1:]
    if not args or args[0] == 'select_file':
        select_file()
