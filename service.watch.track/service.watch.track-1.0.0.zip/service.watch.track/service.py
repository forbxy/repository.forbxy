# -*- coding: utf-8 -*-
"""
Watch Track - 后台服务

触发时机：
    1. track_file 设置变更 (onSettingsChanged) → reload_settings + 后台 sync()
    2. 播放停止/结束 (onPlayBackStopped / onPlayBackEnded) → sync()
    3. 每 check_interval 秒轮询文件 mtime → 若外部修改则 sync()

启动时：延迟 STARTUP_DELAY 秒后做一次 sync（等待 Kodi 库加载完成）。

同步方向：全量双向合并，Kodi 与文件的记录各取最优后双向写回。
"""

import threading
import traceback
import time
import xbmc

from lib.common import log,jsonrpc_request
from lib.sync import SyncManager

STARTUP_DELAY = 10   # 秒，等待 Kodi 视频库初始化完成


# ---------------------------------------------------------------------------
# Monitor：监听设置变更
# ---------------------------------------------------------------------------

class SettingsMonitor(xbmc.Monitor):
    def __init__(self, manager: SyncManager):
        super().__init__()
        self._sync = manager

    def onSettingsChanged(self):
        log('Settings changed, reloading...')
        track_file_changed, old_file_path, new_file_path = self._sync.reload_settings()
        if not track_file_changed:
            return
        if not new_file_path:
            log(f'track_file changed: "{old_file_path}" -> "{new_file_path}", skipping immediate sync because track_file is empty.')
            return

        log(f'track_file changed: "{old_file_path}" -> "{new_file_path}", syncing in background...')
        self._sync.clear_shadow()
        t = threading.Thread(target=self._sync.sync, daemon=True)
        t.start()


# ---------------------------------------------------------------------------
# Player：监听播放事件
# ---------------------------------------------------------------------------

class WatchPlayer(xbmc.Player):
    def __init__(self, manager: SyncManager):
        super().__init__()
        self._sync = manager
        self._is_library_item = False   # 当前播放是否为库中的电影/剧集
        self._sync_timer = None
        self._timer_lock = threading.Lock()

    def onAVStarted(self):
        """播放开始时判断是否为库条目，决定停止时是否同步。"""
        try:
            result = jsonrpc_request({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Player.GetItem',
                'params': {'playerid': 1, 'properties': []},
            })
            if result:
                item = result.get('item', {})
                item_type = item.get('type', '')
                item_id = item.get('id', -1)
                self._is_library_item = (item_type in ('movie', 'episode') and item_id > 0)
                log(f'Playback started: type={item_type} id={item_id} is_library={self._is_library_item}')
            else:
                self._is_library_item = False
        except Exception as e:
            log(f'onAVStarted error: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
            self._is_library_item = False

    def onPlayBackStopped(self):
        self._trigger_export('stopped')

    def onPlayBackEnded(self):
        self._trigger_export('ended')

    def _trigger_export(self, reason: str):
        if not self._sync.sync_on_stop:
            return
        if not self._is_library_item:
            return
        self._is_library_item = False
        
        # 延迟执行，等待 Kodi 写入数据库。
        # 如果连续触发多个停止事件（如快速跳集），则取消旧的 timer 重新计时（防抖）
        with self._timer_lock:
            if self._sync_timer is not None:
                self._sync_timer.cancel()

            def _task():
                log(f'Syncing after playback {reason}...')
                self._sync.sync()

            self._sync_timer = threading.Timer(2, _task)
            self._sync_timer.daemon = True
            self._sync_timer.start()


# ---------------------------------------------------------------------------
# 主服务循环
# ---------------------------------------------------------------------------

def main():
    log('Service starting...')
    sync_mgr = SyncManager()
    monitor = SettingsMonitor(sync_mgr)
    player = WatchPlayer(sync_mgr)

    startup_done = False
    start_time = time.time()
    last_check = start_time

    try:
        while not monitor.abortRequested():
            # waitForAbort 每次最多等 1 秒，保证能及时响应退出请求
            if monitor.waitForAbort(1):
                break

            now = time.time()

            # 启动延迟：等待 Kodi 视频库就绪后做首次 sync
            if not startup_done and (now - start_time) >= STARTUP_DELAY:
                startup_done = True
                log('Startup delay elapsed, doing initial sync...')
                sync_mgr.sync()
                last_check = now

            # 定期轮询文件 mtime，有外部变更则 sync
            elif startup_done and (now - last_check) >= sync_mgr.check_interval:
                sync_mgr.check_and_sync_if_changed()
                last_check = now
                
    finally:
        log('Service stopped.')
        sync_mgr.close()
        del player


if __name__ == '__main__':
    main()
