import xbmc
import xbmcgui
import xbmcaddon
import os
import subprocess
import shutil
import tempfile
import sys
import xbmcvfs
import xml.etree.ElementTree as ET
from urllib.parse import urlparse
import urllib.request
import re

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')

# 缓存 ffmpeg 路径，避免每次调用 get_ffmpeg() 都重复检查文件系统
_ffmpeg_path_cache = None

def L(string_id):
    return ADDON.getLocalizedString(string_id)

def log(msg):
    xbmc.log(f"[{ADDON_NAME}] {msg}", xbmc.LOGINFO)

class TimeSelectDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(TimeSelectDialog, self).__init__(*args, **kwargs)
        self.start_time = 0.0
        self.duration = 5.0
        self.is_confirmed = False
        
    def _fmt(self, val):
        return str(int(val)) if val == int(val) else str(val)
        
    def onInit(self):
        self.setProperty('StartTime', self._fmt(self.start_time))
        self.setProperty('Duration', self._fmt(self.duration))
        
    def onClick(self, controlId):
        if controlId == 100:
            dialog = xbmcgui.Dialog()
            new_val = dialog.input(L(30060), self._fmt(self.start_time))
            if new_val:
                try:
                    self.start_time = float(new_val)
                    if self.start_time < 0: self.start_time = 0.0
                    self.setProperty('StartTime', self._fmt(self.start_time))
                except ValueError:
                    pass
        elif controlId == 101:
            dialog = xbmcgui.Dialog()
            new_val = dialog.input(L(30061), self._fmt(self.duration))
            if new_val:
                try:
                    dur = float(new_val)
                    if dur > 5.0:
                        xbmcgui.Dialog().notification(L(30062), L(30063), xbmcgui.NOTIFICATION_WARNING, 3000)
                        dur = 5.0
                    elif dur <= 0:
                        dur = 5.0
                    self.duration = dur
                    self.setProperty('Duration', self._fmt(self.duration))
                except ValueError:
                    pass
        elif controlId == 200:
            self.is_confirmed = True
            self.close()
        elif controlId == 201:
            self.close()

    def onAction(self, action):
        if action.getId() in [92, 10]: # BACK or ESC
            self.close()

def check_environment():
    if sys.platform != 'linux' or (not os.path.ismount('/flash') and not os.path.exists('/flash')):
        xbmcgui.Dialog().ok(L(30010), L(30011))
        return False
    return True

def get_free_space_mb(path):
    try:
        st = os.statvfs(path)
        return (st.f_bavail * st.f_frsize) / (1024 * 1024)
    except Exception as e:
        log(f"get_free_space_mb failed: {e}")
        return 999  # Fallback if statvfs fails

def get_ffmpeg():
    global _ffmpeg_path_cache
    if _ffmpeg_path_cache and os.path.exists(_ffmpeg_path_cache):
        return _ffmpeg_path_cache
        
    addon = xbmcaddon.Addon()
    addon_profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.exists(addon_profile):
        os.makedirs(addon_profile)
        
    bin_dir = os.path.join(addon_profile, "bin")
    if not os.path.exists(bin_dir):
        os.makedirs(bin_dir)
        
    ffmpeg_path = os.path.join(bin_dir, "ffmpeg")
    
    # 检查是否已经成功下载
    if os.path.exists(ffmpeg_path) and os.path.getsize(ffmpeg_path) > 10 * 1024 * 1024:
        return ffmpeg_path
        
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(L(30020), L(30021)):
        # 用户拒绝，尝试回退系统路径
        for path in ["/opt/bin/ffmpeg", "/usr/bin/ffmpeg", "/bin/ffmpeg"]:
            if os.path.exists(path):
                return path
        return None
        
    progress = xbmcgui.DialogProgress()
    progress.create(L(30022), L(30023))
    
    # 使用 eugeneware 托管的 John Van Sickle 纯静态版 (完美兼容 CoreELEC musl 环境)
    url = "https://gh-proxy.org/https://github.com/eugeneware/ffmpeg-static/releases/download/b6.1.1/ffmpeg-linux-arm64"
    
    try:
        def report_hook(count, block_size, total_size):
            if progress.iscanceled():
                raise Exception(L(30025))
            if total_size > 0:
                percent = int(count * block_size * 100 / total_size)
                percent = min(percent, 100)
                progress.update(percent, L(30024).format(percent, total_size // (1024 * 1024)))
                
        # 直接下载为二进制文件
        urllib.request.urlretrieve(url, ffmpeg_path, reporthook=report_hook)
        
        progress.update(100, L(30026))
        os.chmod(ffmpeg_path, 0o755)
            
        progress.close()
        _ffmpeg_path_cache = ffmpeg_path
        return ffmpeg_path
        
    except Exception as e:
        progress.close()
        if os.path.exists(ffmpeg_path):
            os.remove(ffmpeg_path)
        log(f"FFmpeg download failed: {e}")
        # 下载失败，尝试回退系统路径
        for path in ["/opt/bin/ffmpeg", "/usr/bin/ffmpeg", "/bin/ffmpeg"]:
            if os.path.exists(path):
                xbmcgui.Dialog().notification(L(30027), L(30028), xbmcgui.NOTIFICATION_WARNING)
                return path
                
        dialog.ok(L(30027), L(30029).format(str(e)))
        return None

def is_vfs_path(filepath):
    return "://" in filepath and not filepath.startswith("file://")

def get_dimensions(filepath):
    try:
        ffmpeg_bin = get_ffmpeg()
        if not ffmpeg_bin: return None, None, 20.0
        
        log(f"Parsing media: {filepath}")
        
        real_path = filepath[7:] if filepath.startswith("file://") else filepath
        cmd = [ffmpeg_bin, "-i", real_path]
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stderr = p.stderr
        
        output = stderr.decode('utf-8', errors='ignore')
        log(f"ffmpeg get_dimensions output:\n{output}")
        
        fps = 20.0
        fps_match = re.search(r'(\d+(?:\.\d+)?)\s+fps', output)
        if not fps_match:
            fps_match = re.search(r'(\d+(?:\.\d+)?)\s+tbr', output)
        if fps_match:
            try:
                fps = float(fps_match.group(1))
            except Exception:
                pass
        
        match = re.search(r'Video:.*?\s(\d{2,5})x(\d{2,5})', output)
        if match:
            width, height = int(match.group(1)), int(match.group(2))
            log(f"Parsed: width={width}, height={height}, fps={fps}")
            return width, height, fps
            
        log("Warning: Could not parse resolution from ffmpeg output")
        return None, None, 20.0
    except Exception as e:
        log(f"get_dimensions failed: {e}")
        return None, None, 20.0

def generate_splash():
    
    dialog = xbmcgui.Dialog()
    filepath = dialog.browse(1, L(30030), 'video', '.gif|.png|.apng|.mp4|.mkv|.avi|.mov|.webm|.jpg|.jpeg|.bmp', False, False, '')
    
    if not filepath:
        return
        
    if is_vfs_path(filepath):
        dialog.ok(L(30031), L(30032))
        return
        
    width, height, original_fps = get_dimensions(filepath)
    if width is None or height is None:
        dialog.ok(L(30040), L(30041))
        return
        
    ext = os.path.splitext(filepath)[1].lower()
    is_static = False
    if ext in ['.jpg', '.jpeg', '.bmp']:
        is_static = True
    elif ext == '.png':
        # Prompt user if this PNG is a static image or an animated APNG
        is_static = dialog.yesno(L(30033), L(30034), yeslabel=L(30035), nolabel=L(30036))
        
    scale_to_1080p = False
    if width > 1920 or height > 1080:
        scale_to_1080p = True
    elif width < 1920 and height < 1080:
        ret = dialog.yesno(L(30050), L(30051).format(width, height), yeslabel=L(30052), nolabel=L(30053))
        scale_to_1080p = ret

    bg_color = "black"
    if not scale_to_1080p and (width < 1920 or height < 1080):
        ret_bg = dialog.yesno(L(30054), L(30055), yeslabel=L(30056), nolabel=L(30057))
        bg_color = "white" if ret_bg else "black"

    if not is_static:
        addon_path = ADDON.getAddonInfo('path')
        time_dialog = TimeSelectDialog('script-gen-ce-boot-animation-timeselect.xml', addon_path, 'Default', '1080i')
        time_dialog.doModal()
        
        if not time_dialog.is_confirmed:
            del time_dialog
            return
            
        start_time = time_dialog.start_time
        max_duration = time_dialog.duration
        del time_dialog

    temp_dir = tempfile.mkdtemp(prefix="ce_splash_")
    
    try:
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, L(30080))
        progress.update(10)
        
        offset_x = 0
        offset_y = 0
        
        real_path = filepath[7:] if filepath.startswith("file://") else filepath
        
        if is_static:
            progress.create(ADDON_NAME, L(30080)) # Processing...
            progress.update(10)
            
            if scale_to_1080p:
                ratio = min(1920.0 / width, 1080.0 / height)
                scaled_w = int(width * ratio)
                scaled_h = int(height * ratio)
                scaled_w -= scaled_w % 2
                scaled_h -= scaled_h % 2
                vf = f"scale={scaled_w}:{scaled_h},pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color={bg_color}"
            else:
                vf = f"pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color={bg_color}"
                
            cmd_static = [
                get_ffmpeg(), "-y", 
                "-i", real_path,
                "-vf", vf,
                "-vframes", "1",
                "-pix_fmt", "rgb24",
                "-pred", "none",
                os.path.join(temp_dir, "oemsplash-1080-0.png")
            ]
            subprocess.run(cmd_static, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            progress.update(70, L(30081))
            
            config_path = os.path.join(temp_dir, "oemsplash-1080-config")
            with open(config_path, 'w') as f:
                f.write("animation_enable=0\n")
        else:
            # 根据实际输出分辨率动态调整帧率上限
            if scale_to_1080p or (width > 1280 or height > 720):
                ret_fps = dialog.yesno(L(30070), L(30071), yeslabel=L(30072), nolabel=L(30073))
                max_fps = 30 if ret_fps else 15
            else:
                max_fps = 30
            
            fps = int(round(original_fps)) if original_fps > 0 else max_fps
            fps = min(fps, max_fps)
            max_frames = fps * 5  # 最大 5 秒
            
            # 1. Generate Base Frame (1080p with selected background color)
            cmd_base = [
                get_ffmpeg(), "-y", "-f", "lavfi", "-i", f"color=c={bg_color}:s=1920x1080",
                "-vframes", "1", os.path.join(temp_dir, "oemsplash-1080-0.png")
            ]
            subprocess.run(cmd_base, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            progress.update(30)
            
            # 2. Extract Animation Frames
            output_pattern = os.path.join(temp_dir, "oemsplash-1080-%d.png")

            cmd_extract = [
                get_ffmpeg(), "-y", 
                "-ss", str(start_time),
                "-i", real_path,
                "-t", str(max_duration),
                "-r", str(fps),
                "-vframes", str(max_frames),
                "-map", "0:v:0",
                "-pix_fmt", "rgb24",
                "-pred", "sub",
                "-start_number", "1", 
                "-vcodec", "png"
            ]
            
            if scale_to_1080p:
                cmd_extract.extend(["-vf", "scale=1920:1080:force_original_aspect_ratio=decrease"])
                ratio = min(1920.0 / width, 1080.0 / height)
                scaled_w = int(width * ratio)
                scaled_h = int(height * ratio)
                offset_x = (1920 - scaled_w) // 2
                offset_y = (1080 - scaled_h) // 2
            else:
                offset_x = (1920 - width) // 2
                offset_y = (1080 - height) // 2
                
            cmd_extract.append(output_pattern)
            
            log(f"ffmpeg extract cmd:\n{' '.join(cmd_extract)}")
            
            p = subprocess.run(cmd_extract, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            returncode, stderr = p.returncode, p.stderr
                
            if returncode != 0:
                raise Exception(f"ffmpeg failed: {stderr.decode('utf-8', errors='ignore')[:500]}")
                
            progress.update(70, L(30081))
            
            # 验证是否成功生成了新帧
            if len(os.listdir(temp_dir)) <= 2:
                raise Exception(L(30086).format(p.stderr.decode('utf-8', errors='ignore')[:300]))
            
            # 3. Create config
            config_path = os.path.join(temp_dir, "oemsplash-1080-config")
            with open(config_path, 'w') as f:
                f.write("animation_enable=1\n")
                f.write(f"animation_offset_x={offset_x}\n")
                f.write(f"animation_offset_y={offset_y}\n")
                f.write(f"frames_per_second={fps}\n")
            
        # 3.5 Check exact size vs Free space
        progress.update(80, L(30082))
        total_bytes = sum(os.path.getsize(os.path.join(temp_dir, f)) for f in os.listdir(temp_dir) if os.path.isfile(os.path.join(temp_dir, f)))
        total_mb = total_bytes / (1024 * 1024)
        free_mb = get_free_space_mb('/flash')
        
        old_bytes = 0
        flash_progress_dir = "/flash/progress"
        if os.path.exists(flash_progress_dir):
            for f in os.listdir(flash_progress_dir):
                if f.startswith("oemsplash-1080-"):
                    old_path = os.path.join(flash_progress_dir, f)
                    if os.path.isfile(old_path):
                        old_bytes += os.path.getsize(old_path)
        old_mb = old_bytes / (1024 * 1024)
        effective_free_mb = free_mb + old_mb
        
        # 必须预留至少 20MB 的安全余量，防止 /flash 写满导致系统崩溃
        if total_mb + 20 > effective_free_mb:
            raise Exception(L(30083).format(total_mb, effective_free_mb))
            
        # 4. Deploy to /flash
        progress.update(85, L(30084))
        
        os.system("mount -o rw,remount /flash")
        try:
            flash_progress_dir = "/flash/progress"
            if not os.path.exists(flash_progress_dir):
                os.makedirs(flash_progress_dir)
            else:
                # 必须先清空老动画的残留帧，否则新旧帧会混在一起
                for filename in os.listdir(flash_progress_dir):
                    if filename.startswith("oemsplash-1080-"):
                        try:
                            os.remove(os.path.join(flash_progress_dir, filename))
                            log(f"Cleaned old frame: {filename}")
                        except Exception as e:
                            log(f"Failed to delete: {filename}, error: {e}")
                            
            temp_files = os.listdir(temp_dir)
            log(f"Deploying {len(temp_files)} files to /flash/progress...")
                
            copied_count = 0
            for filename in temp_files:
                src = os.path.join(temp_dir, filename)
                dst = os.path.join(flash_progress_dir, filename)
                try:
                    shutil.copy2(src, dst)
                    log(f"Copied: {filename} ({os.path.getsize(src)} bytes)")
                    copied_count += 1
                except Exception as e:
                    log(f"Copy failed: {filename}, error: {e}")
            
            log(f"Deploy stats: planned={len(temp_files)}, copied={copied_count}")
                
        finally:
            log("Remounting /flash as read-only")
            os.system("mount -o ro,remount /flash")
        
        progress.update(100, L(30085))
        progress.close()
        dialog.ok(L(30090), L(30091))
        
    except subprocess.CalledProcessError as e:
        if 'progress' in locals(): progress.close()
        error_msg = e.stderr.decode('utf-8', errors='ignore') if e.stderr else str(e)
        dialog.ok(L(30040), L(30092).format(error_msg))
    except Exception as e:
        if 'progress' in locals(): progress.close()
        dialog.ok(L(30040), L(30093).format(str(e)))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def remove_splash():
    if not check_environment():
        return
        
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(L(30100), L(30101)):
        return
        
    try:
        os.system("mount -o rw,remount /flash")
        try:
            flash_progress_dir = "/flash/progress"
            if os.path.exists(flash_progress_dir):
                for filename in os.listdir(flash_progress_dir):
                    if filename.startswith("oemsplash-1080-"):
                        os.remove(os.path.join(flash_progress_dir, filename))
        finally:
            os.system("mount -o ro,remount /flash")
        dialog.ok(L(30090), L(30102))
        
    except Exception as e:
        dialog.ok(L(30040), L(30103).format(str(e)))

def main():
    if not check_environment():
        return
        
    # 在进入主菜单前，优先确保底层核心组件已就绪
    if not get_ffmpeg():
        return
        
    dialog = xbmcgui.Dialog()
    options = [L(30001), L(30002)]
    ret = dialog.select(L(30003), options)
    
    if ret == 0:
        generate_splash()
    elif ret == 1:
        remove_splash()

if __name__ == '__main__':
    main()
