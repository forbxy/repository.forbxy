# CoreELEC Boot Animation Generator

---

一款适用于 CoreELEC 系统的 Kodi 插件，可从 GIF、APNG 动图或 MP4/MKV 等本地视频文件中截取片段，一键生成并部署为开机加载动画。

---

A Kodi addon for CoreELEC that extracts clips from local GIF, APNG, or video files (MP4/MKV/etc.) to generate and deploy custom boot animations with one click.
