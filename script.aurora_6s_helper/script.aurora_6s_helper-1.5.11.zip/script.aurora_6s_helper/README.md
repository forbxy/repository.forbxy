# 极光 4 Pro / 6S 助手

为腾讯极光 4 Pro（A4111）和 6S（A4112）提供无线修复、RGB 灯条控制与 eMMC 双系统管理。
支持 6S、4 Pro RTL8852 和 4 Pro AP6275P，适用于 CoreELEC Amlogic-ng 21.x、Amlogic-no 22.x。

## 插件功能

### Wi-Fi、蓝牙与遥控器修复

- 自动识别 NG / NO 分支，通过原厂 Android 属性区分 A4111 / A4112；未挂载 Android 时按 `active_slot` 选择 A/B 元数据，临时只读映射完整 vendor 获取机型，读取后卸载。当前 DTB 的名称不作为实物机型依据。
- A4111 根据 S905X4 芯片修订号选择无线版本：rev A/B/C 为 AP6275P，rev D 为 RTL8852，修复前由用户选择实物是 4 Pro 还是 6S，再安装对应 DTB；A4112 自动识别为 6S，使用 RTL8852。PCIe 已枚举时使用实际芯片 ID 交叉核对，未枚举时也能读取 CPU 修订号。
- 支持手动确认 4 Pro / 6S，适用于使用通用或 Ugoos X4 等设备树、且无法取得原厂机型的情况。
- RTL8852 NG 安装 Wi-Fi、灯条驱动并配置独立的开机启动服务，驱动加载不依赖 Kodi。
- RTL8852 NO 提供蓝牙配置；所有 NO 机型/无线版本均提供 Zidoo V12 输入识别修复，NG 不安装这条规则。
- AP6275P NG 使用系统自带的博通 Wi-Fi/蓝牙支持，安装专用 DTB 与独立灯条驱动服务；迁移时备份并清理旧 Realtek NG 驱动文件、配置和强制启动项。
- AP6275P NO 安装对应 DTB 及 V12 识别规则，使用 CE 自带的博通 Wi-Fi/蓝牙驱动和固件。
- 安装前检查兼容性并备份原文件，支持恢复；部署失败时尝试自动回退。

### RGB 灯条控制

- 分别设置常规状态和播放状态的颜色、亮度及效果。
- 支持常亮、呼吸和关闭，呼吸提供快、中、慢三档速度。
- 支持 Kodi 原生色块选色，也可精确输入 RGB 十六进制色值。
- 支持硬件平滑呼吸；可关闭平滑优先选项，以保留独立 RGB 亮度档位。
- 灯控运行依据已安装的专用 DTB 和灯控设备，不依赖 Android 机型读取；安装硬件修复仍单独核对机型。
- 开机后自动应用保存的设置，播放音频或视频时切换灯光，停止播放后恢复常规状态。
- 保存设置后按当前播放状态立即应用，支持查看当前灯光状态。

### eMMC 双系统、备份与还原（NO 22.x / NG 21.x 测试）

- 仅接受原厂 Android 属性明确识别的 **A4111 / A4112**，两者使用同一套流程，不按 Wi-Fi/蓝牙芯片区分。不接受通过借用 DTB 或手动确认绕过机型检查。
- **安装双系统**：将当前外置 CE（设置、插件及数据）迁入 eMMC；可按 1 GiB 步进选择 Android 用户数据容量（至少 8 GiB，不含系统分区）；扣除原厂系统分区、1 GiB CE 启动区和分区间隔后，其余空间分给 CE 数据区。仅提供能容纳当前 CE 数据及预留空间的选项。兼容此前固定 20 GiB CE 数据区布局的移除、备份与还原；再次调整容量需重新安装并重置 Android。保留 Android 系统分区，重置其应用、账号和用户文件。
- **移除内置 CE**：恢复原厂 userdata 的起点和容量，保留 Android 系统分区；内置 CE 和 Android 用户数据都将清除。Android 下次启动重新初始化。
- **完整备份**：备份 eMMC 用户区、boot0、boot1，保存本机 CID/容量/机型及 SHA-256，并独立读回核验。备份不需要重启。
- **完整还原**：仅允许还原同一 eMMC、同一机型和容量的完整备份。写入前对全部镜像各完整校验一次，再写入、读回验证；分别显示校验、写入和读回进度；boot0/boot1 内容相同时跳过写入。缺少 CID 的旧研究备份，只有补充经核对的历史身份记录后才能被识别；原始记录和镜像保持不变，执行还原前仍完整校验镜像。
- 还原写盘前暂停占用 Android 分区的 TEE 服务；写盘前失败会恢复原先运行的服务，写入后保持暂停直到重启。
- 操作必须从 **外置 SD / USB 的 CE** 发起，备份保存在外置 `/storage/aurora-emmc-backups/`。手动备份需要容纳一份完整 eMMC 镜像的可用空间；安装需要 CE 快照和暂存空间，移除、还原不再预留整盘备份空间。
- **仅“完整备份”入口会生成整盘备份**。安装、移除、还原都不自动备份，也不要求已有备份；如需保留当前状态，应先手动备份。安装时暂存当前外置 CE 用于迁移，不是 eMMC 备份。
- 写盘前明确提示 **Android 将重置、数据覆盖风险，以及“插件作者不对刷双系统或备份还原造成的损失负责”**，用户取消不会启动任务。
- 操作在插件前台执行，显示百分比和“已处理 / 总量”（含复制、校验各阶段），不再创建 systemd 后台写盘任务。安装保持 Kodi 运行；开始前请停止播放、媒体库同步、扫描和刮削，操作期间不要退出 Kodi。写盘前可以请求取消，写盘开始后不能取消。
- 安装保留文件的扩展属性和访问控制属性，即使系统 rsync 未编译相关支持也会单独复制并校验。安装复制当前外置 CE 到暂存目录，不再检查运行中源文件是否保持不变，也不对 SQLite 做专门快照；用户需按提示停止相关活动。暂存文件及写入 eMMC 后的读回校验保留。
- 安装通过严格限定起点、长度的 loop 设备完成写入，**不需要中途重启**；完成后关机、拔下外置盘再开机。安装器不会自动重启。
- 仅接受已核对的 MPT 布局和启动脚本，不能用于第三方任意双系统布局。备份不包含 RPMB/eFuse/硬件配置，不是线刷包，也不保证硬件绑定加密数据一定可恢复。

1.5.5 将 NG/NO 底层磁盘操作拆为独立模块，并修复 NG rsync 缺少扩展属性支持导致的安装失败；实机临时镜像复制和读回校验已通过。此前 NG 移除失败也已修复并完成核对。NG 21.x 仍为测试支持。NG 使用自身原版 cfgload；支持 32 位用户空间，并可临时只读映射原厂 Android vendor 获取机型，读取后卸载。已通过 NG 实机只读预检查、受限只读 loop 与临时镜像元数据演练；完整 NG 内置安装及启动仍待验证。1.5.2 可选容量版本已部署。早期后端已通过盒子上临时镜像的布局/边界演练；1.4.x 移除已核对实机分区结果，前台安装、备份、还原仍需端到端验证。原先的 4 Pro 分阶段安装和实际双向启动已有验证，不能等同于新集成流程全部通过。6S 使用相同布局检查，尚未实测新安装器。技术记录见 [eMMC 后端说明](resources/emmc/README.md)。

## 驱动源码来源

| 组件 | 源码来源 |
| --- | --- |
| RTL8852BE Wi-Fi 驱动及内存模块（`8852be.ko`、`rtkm.ko`） | [CoreELEC/RTL8852BE-aml](https://github.com/CoreELEC/RTL8852BE-aml/tree/5da5adca92ac38a6c3a782147d45e48da577dce3) |
| TCA6507 灯条驱动（`leds-tca6507.ko`） | [CoreELEC/linux-amlogic — leds-tca6507.c](https://github.com/CoreELEC/linux-amlogic/blob/50c8e8154c5aba3c7cd8438d04dd5fdd51733e41/drivers/leds/leds-tca6507.c) |
| Realtek 蓝牙配置（`rtl8852bs_config`） | 基于 [CoreELEC/rtkbt-firmware-aml](https://github.com/CoreELEC/rtkbt-firmware-aml) 的配置进行修复 |
| AP6275P / BCM43752 Wi-Fi（NG/NO 系统自带博通驱动，插件不附带模块） | [CoreELEC/ap6xxx-aml](https://github.com/CoreELEC/ap6xxx-aml/tree/f0130717e2cdfc0d339a10e5b430ef15ee6b0c29) |

插件打包的 NG 驱动模块编译自上述固定提交。蓝牙使用 CoreELEC 自带的驱动和启动服务，RTL8852 使用插件提供的修复配置，AP6275P 使用系统博通固件。

## 修复数据目录

数据按 `resources/payload/{ng,no}/{6s,4pro}` 整理；4 Pro 再分为 `ap6275p` 和 `rtl8852`。
已收录 6S NG/NO、4 Pro RTL8852 NG/NO，以及 4 Pro AP6275P NG/NO。
4 Pro RTL8852 采用与 6S 相同的修复方案，DTB 仅更改机型名称和标识；该变体尚未进行实机验证。
详细文件布局见 [payload 说明](resources/payload/README.md)。

## eMMC 相关源码来源

- 安装逻辑来自本项目 `CE_android/tools` 已有研究流程，集成后增加双机型检查、限定范围的 loop 映射、任务管理、移除与备份还原。
- 分区候选生成使用 [7Ji/ampart](https://github.com/7Ji/ampart/tree/1539ff2f6fa73ef78dfde3ac585fb9c93244e85e)，仅对临时稀疏镜像运行；不让 ampart 直接修改真实 eMMC。附带 GPL-3.0 源码和许可。
- 对照参考 [AM9 Pro 开源安装器](https://github.com/dangerouslaser/ugoos-am9-pro-coreelec-emmc/blob/581ca4f7a441461b957d814cc9beb1a1cca6cfe5/ce-emmc-install.sh) 的分区重读处理；本助手保留 Amlogic MPT，不采用该项目清除 MPT / 改用 GPT 的流程。
