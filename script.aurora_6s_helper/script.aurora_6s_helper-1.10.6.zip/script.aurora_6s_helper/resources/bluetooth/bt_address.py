"""Deferred Broadcom host-address alignment; preserve the old adapter's bonds."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex

from bt_diagnostics import log, stage
from bt_pairing import mac
from bt_support import atomic, run

UNIT = 'brcmfmac_sdio-firmware-aml.service'
SYSTEMD = Path('/storage/.config/system.d')
DROPIN = SYSTEMD/(UNIT+'.d')/'90-aurora-android-bt-address.conf'
STATE = Path('/storage/.cache/aurora-android-bluetooth/address-change.json')
BLUETOOTH = Path('/sys/class/bluetooth')
PCI = Path('/sys/bus/pci/devices')
PROC = Path('/proc')
ATTACH = Path('/usr/bin/hciattach')


def real_path(path):
    for item in (path, *path.parents):
        if item.is_symlink():
            raise ValueError('蓝牙地址配置路径不可包含符号链接')


def state():
    real_path(STATE)
    if not STATE.exists():
        return None
    if not STATE.is_file() or STATE.stat().st_size > 16384:
        raise ValueError('蓝牙地址恢复记录无效')
    value = json.loads(STATE.read_text())
    if value.get('status') == 'rolled_back':
        return None
    if value.get('format') != 1 or value.get('status') not in ('prepared', 'installed'):
        raise ValueError('蓝牙地址恢复记录格式不支持')
    for field in ('old_address', 'android_address'):
        value[field] = host_address(value[field])
    return value


def host_address(value):
    value = mac(value)
    if value == '00:00:00:00:00:00' or int(value[:2], 16) & 1:
        raise ValueError('蓝牙主机地址不是有效的单播地址')
    return value


def unit_info():
    output = run(['systemctl', 'show', UNIT, '--no-pager',
                  '--property=LoadState,ActiveState,MainPID,ExecStart,DropInPaths']).decode()
    return dict(line.split('=', 1) for line in output.splitlines() if '=' in line)


def start_arguments(info):
    matches = re.findall(r'argv\[\]=([^;]+?)\s*;', info.get('ExecStart', ''))
    if len(matches) != 1:
        raise ValueError('博通初始化服务的启动命令无法确定')
    args = shlex.split(matches[0])
    prefix = [str(ATTACH), '-n', '-s', '115200', '/dev/ttyS1', 'bcm43xx', '2000000']
    if (args[:7] != prefix or len(args) not in (7, 8, 9, 10)
            or (len(args) >= 8 and args[7] not in ('flow', 'noflow'))
            or (len(args) >= 9 and args[8] not in ('sleep', 'nosleep'))):
        raise ValueError('博通初始化命令不是已支持的 UART/bcm43xx 配置')
    if len(args) == 10:
        host_address(args[9])
    return args


def changed_arguments(args, address):
    # BlueZ's bcm43xx profile defaults to FLOW_CTL / DISABLE_PM.
    # Preserve those defaults, and any flags explicitly present in ExecStart.
    result = list(args[:9])
    if len(result) == 7:
        result.append('flow')
    if len(result) == 8:
        result.append('nosleep')
    return result + [host_address(address)]


def content(args, address):
    return ('# Managed by Aurora Android Bluetooth import\n[Service]\nExecStart=\nExecStart='
            + ' '.join(changed_arguments(args, address)) + '\n').encode()


@stage('adapter.broadcom', '核对板载博通芯片与地址修改条件')
def plan(payload, current):
    target = host_address(payload['host'])
    current = host_address(current)
    if payload.get('model') != 'A4111' or payload.get('branch') not in ('Amlogic-ng', 'Amlogic-no'):
        raise ValueError('自动对齐地址目前仅支持已确认的 4 Pro AP6275P 板载博通方案')
    controllers = sorted(path.name for path in BLUETOOTH.glob('hci*')
                         if re.fullmatch(r'hci[0-9]+', path.name))
    if controllers != ['hci0']:
        raise ValueError('自动对齐要求唯一的 hci0 板载适配器，请先移除额外蓝牙适配器')
    ids = set()
    for path in PCI.iterdir():
        if (path/'vendor').is_file() and (path/'device').is_file():
            ids.add((int((path/'vendor').read_text(), 16), int((path/'device').read_text(), 16)))
    if (0x14e4, 0x449d) not in ids or (0x10ec, 0xb852) in ids:
        raise ValueError('未确认 AP6275P 的博通 PCI ID，拒绝修改蓝牙地址')
    hci = run(['hciconfig', 'hci0', '-a']).decode(errors='replace')
    if (not re.search(r'Bus:\s*UART\b', hci)
            or not re.search(r'Manufacturer:.*\(15\)', hci)
            or not re.search(r'BD Address:\s*'+re.escape(current)+r'\b', hci, re.I)):
        raise ValueError('实时蓝牙控制器未确认为同一块博通 UART，拒绝修改地址')
    real_path(DROPIN)
    previous = state()
    if previous:
        raise ValueError('已有地址对齐配置，请先重启使其生效，或恢复原 CE 蓝牙地址后再导入')
    if DROPIN.exists():
        raise ValueError('地址覆盖文件已存在但没有恢复记录，请检查现有配置')
    info = unit_info()
    if info.get('LoadState') != 'loaded' or info.get('ActiveState') != 'active':
        raise ValueError('博通蓝牙初始化服务未正常运行，请先修复硬件')
    args = start_arguments(info)
    if len(args) == 10 and args[9].upper() != current:
        raise ValueError('现有初始化地址与控制器实时地址不一致，请先检查固件配置')
    pid = info.get('MainPID', '')
    if not pid.isdecimal() or int(pid) <= 0:
        raise ValueError('无法核对博通初始化进程')
    process = PROC/pid
    if (process/'exe').resolve() != ATTACH.resolve():
        raise ValueError('博通初始化进程的实际程序不匹配')
    actual = [part.decode() for part in (process/'cmdline').read_bytes().split(b'\0') if part]
    if not actual or actual[0] not in (str(ATTACH), ATTACH.name) or actual[1:] != args[1:]:
        raise ValueError('博通初始化进程参数与服务不一致')
    result = {'old_address': current, 'android_address': target, 'unit': UNIT, 'original_argv': args}
    log('alignment_available', 'adapter.broadcom', old_address=current, android_address=target,
        chip='AP6275P / BCM4362A2', takes_effect='reboot')
    return result


def write_dropin(data):
    real_path(DROPIN)
    DROPIN.parent.mkdir(parents=True, exist_ok=True)
    temporary = DROPIN.with_name(DROPIN.name+'.new')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(DROPIN)
    finally:
        temporary.unlink(missing_ok=True)


@stage('adapter.configure', '保存博通地址覆盖与恢复记录（重启生效）')
def install(change, backup):
    real_path(DROPIN)
    if state() or DROPIN.exists():
        raise ValueError('蓝牙地址配置已变化，请重新读取')
    data = content(change['original_argv'], change['android_address'])
    saved = {**change, 'format': 1, 'status': 'prepared', 'backup': str(backup),
             'dropin_sha256': hashlib.sha256(data).hexdigest()}
    original = run(['systemctl', 'cat', UNIT, '--no-pager'])
    saved_unit = backup/'bluetooth-init.service.txt'
    saved_unit.write_bytes(original)
    saved_unit.chmod(0o600)
    # Persist recovery intent before touching systemd configuration. The original
    # adapter directory and identity remain in place; no keys enter this record.
    atomic(backup/'address-change.json', saved)
    STATE.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    atomic(STATE, saved)
    try:
        write_dropin(data)
        run(['systemctl', 'daemon-reload'])
        verify = unit_info()
        if (str(DROPIN) not in shlex.split(verify.get('DropInPaths', ''))
                or start_arguments(verify) != changed_arguments(change['original_argv'], change['android_address'])):
            raise ValueError('系统未加载预期的博通地址覆盖，已停止导入')
        saved['status'] = 'installed'
        atomic(STATE, saved)
    except Exception as error:
        try:
            rollback()
        except Exception as rollback_error:
            error._bt_address_recovery = str(STATE)
            log('rollback_incomplete', 'adapter.configure', recovery_record=str(STATE))
        raise
    log('pending_reboot', 'adapter.configure', old_address=change['old_address'],
        android_address=change['android_address'], backup=str(backup))


@stage('adapter.rollback', '恢复原 CE 蓝牙地址配置（重启生效）')
def rollback():
    saved = state()
    if not saved:
        raise ValueError('没有助手保存的蓝牙地址覆盖可恢复')
    args = start_arguments({'ExecStart': 'argv[]='+' '.join(saved['original_argv'])+' ;'})
    real_path(DROPIN)
    if DROPIN.exists():
        if not DROPIN.is_file() or hashlib.sha256(DROPIN.read_bytes()).hexdigest() != saved['dropin_sha256']:
            raise ValueError('博通地址覆盖已被其他操作修改，保留恢复记录，请先检查配置')
        DROPIN.unlink()
    run(['systemctl', 'daemon-reload'])
    if start_arguments(unit_info()) != args:
        raise ValueError('恢复后的博通初始化命令与备份不一致，请检查日志和原服务配置')
    atomic(STATE, {**saved, 'status': 'rolled_back'})
    log('restored', 'adapter.rollback', old_address=saved['old_address'], backup=saved['backup'])
    return {'old_address': saved['old_address'], 'android_address': saved['android_address'],
            'backup': saved['backup'], 'reboot_required': True}
