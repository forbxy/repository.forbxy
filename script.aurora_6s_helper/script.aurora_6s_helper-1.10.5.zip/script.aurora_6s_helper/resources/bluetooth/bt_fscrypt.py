"""Read-only fscrypt v2 helpers, adapted from the 6 Pro research."""
import hmac, socket, struct

def derive(master, context, info, length):
    if len(master) != 64 or not 0 < length <= 64:
        raise ValueError('Unsupported fscrypt key length')
    prk = hmac.digest(bytes(64), master, 'sha512')
    return hmac.digest(prk, b'fscrypt\0' + bytes([context]) + info + b'\x01', 'sha512')[:length]


def cipher(name, key, iv, data, encrypt):
    """Use the same kernel CTS/XTS implementations as fscrypt; keys stay in RAM."""
    with socket.socket(socket.AF_ALG, socket.SOCK_SEQPACKET, 0) as alg:
        alg.bind(('skcipher', name))
        alg.setsockopt(socket.SOL_ALG, socket.ALG_SET_KEY, key)
        connection, _ = alg.accept()
        with connection:
            connection.settimeout(10)
            controls = [(socket.SOL_ALG, socket.ALG_SET_OP,
                         struct.pack('I', socket.ALG_OP_ENCRYPT if encrypt else socket.ALG_OP_DECRYPT)),
                        (socket.SOL_ALG, socket.ALG_SET_IV, struct.pack('I', len(iv)) + iv)]
            if connection.sendmsg([data], controls) != len(data):
                raise ValueError('Short fscrypt cipher request')
            result = connection.recv(len(data))
            if len(result) != len(data):
                raise ValueError('Short fscrypt cipher response')
            return result


def context(row, master):
    values = [bytes.fromhex(value) for name, value in row['attrs'] if name == '63']
    if (len(values) != 1 or len(values[0]) != 40 or
            values[0][:8] != bytes((2, 1, 4, 2, 0, 0, 0, 0))):
        raise ValueError('Unsupported fscrypt policy in Android system configuration')
    value = values[0]
    if not hmac.compare_digest(value[8:24], derive(master, 1, b'', 16)):
        raise ValueError('System DE key does not match configuration policy')
    return value


def entry_name(row, name, master):
    raw = bytes.fromhex(name)
    if not row['flags'] & 0x800:
        return raw
    ctx = context(row, master)
    key = derive(master, 2, ctx[24:], 32)
    return cipher('cts(cbc(aes))', key, bytes(16), raw, False).rstrip(b'\0')



import os
import stat

class Filesystem:
    def __init__(self, mapped, raw, rows):
        self.rows = rows
        self.master = None
        self.metadata = os.open(mapped, os.O_RDONLY)
        self.raw = os.open(raw, os.O_RDONLY)

    def children(self, row):
        if not stat.S_ISDIR(row['mode']):
            raise ValueError('Expected directory')
        self.require_key(row)
        found = {}
        for inode, _, name in row['entries']:
            if name in ('2e', '2e2e'):
                continue
            decoded = entry_name(row, name, self.master)
            if not decoded or b'/' in decoded or b'\0' in decoded or decoded in found:
                raise ValueError('Invalid filename')
            found[decoded] = self.rows[inode]
        return found

    def lookup(self, *parts):
        row = self.rows[2]
        for part in parts:
            row = self.children(row)[part.encode()]
        return row

    def read(self, row):
        if not stat.S_ISREG(row['mode']) or not 0 < row['size'] <= 4 * 1024**2:
            raise ValueError('Unsupported file')
        self.require_key(row)
        count = (row['size'] + 4095) // 4096
        blocks = {}
        if any(extent[3] for extent in row['extents']):
            raise ValueError('Unwritten extents')
        for logical, physical, length in row['blocks']:
            for i in range(length):
                if logical + i in blocks:
                    raise ValueError('Overlapping blocks')
                blocks[logical + i] = physical + i
        if set(blocks) != set(range(count)):
            raise ValueError('Sparse or preallocated file')
        encrypted = bool(row['flags'] & 0x800)
        key = derive(self.master, 2, context(row, self.master)[24:], 64) if encrypted else None
        result = []
        for logical in range(count):
            block = os.pread(self.raw if encrypted else self.metadata, 4096, blocks[logical] * 4096)
            if len(block) != 4096:
                raise ValueError('Short file read')
            if encrypted:
                block = cipher('xts(aes)', key, logical.to_bytes(16, 'little'), block, False)
            result.append(block)
        return b''.join(result)[:row['size']]

    def require_key(self, row):
        if row['flags'] & 0x800 and self.master is None:
            raise ValueError('安卓文件或目录仍有文件级加密，当前读取方式缺少对应密钥；此固件格式尚未支持')

    def close(self):
        os.close(self.metadata)
        os.close(self.raw)
