"""Use factory Keymaster with a writable RAM copy of its secure store."""
import contextlib
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

from bt_support import atomic, run
from bt_tee_restore import restore, alive
from bt_diagnostics import stage, log, clean


NATIVE = Path('/usr/sbin/tee-supplicant')
PIDFILE = Path('/run/tee-supplicant.pid')
PROC = Path('/proc')
RELEASE = Path('/etc/os-release')
NG_LINK = Path('/var/lib/teetz')
NO_LINK = Path('/var/lib/optee_armtz')
NO_LIBRARY = Path('/usr/lib/optee_armtz')
STOCK_TAS = Path('/usr/lib/ta/S905X4')


@stage('tee.configuration', '检查 TEE 启动方式')
def configuration():
    """Recognize the shipped NG process or NO native/Android loader exactly."""
    pid = int(PIDFILE.read_text())
    executable = os.readlink(PROC/str(pid)/'exe')
    argv = [x.decode() for x in (PROC/str(pid)/'cmdline').read_bytes().split(b'\0') if x]
    native = executable == str(NATIVE) and argv in ([str(NATIVE)], [NATIVE.name])
    release = dict(line.split('=', 1) for line in RELEASE.read_text().splitlines()
                   if '=' in line and not line.startswith('#'))
    no = release.get('DISTRO_DEVICE', '').strip('"') == 'Amlogic-no'
    log('observed', 'tee.configuration', branch='no' if no else 'ng', executable=clean(executable),
        argv0_form='absolute' if argv and argv[0].startswith('/') else 'short', argument_count=len(argv),
        ta_link_present=(NO_LINK if no else NG_LINK).is_symlink())
    if no:
        android = (len(argv) == 2 and argv[0] in ('/system/bin/bootstrap/linker', '/system/bin/bootstrap/linker64')
                   and argv[1] == '/vendor/bin/tee-supplicant'
                   and executable == str(Path(argv[0]).resolve()) and Path(argv[1]).is_file())
        if not (native or android):
            raise ValueError('当前 NO TEE 启动方式尚未支持')
        if not NO_LIBRARY.is_symlink() or os.readlink(NO_LIBRARY) != str(NO_LINK):
            raise ValueError('当前 NO TEE 目录布局尚未支持')
        link = NO_LINK
        if link.is_symlink():
            if link.resolve() != STOCK_TAS:
                raise ValueError('当前 NO TEE 目录已被修改')
        elif link.exists():
            raise ValueError('当前 NO TEE 目录不可临时切换')
        mode = 'no'
    else:
        if not native or not NG_LINK.is_symlink() or NG_LINK.resolve() != STOCK_TAS:
            raise ValueError('当前 NG TEE 目录或启动方式尚未支持')
        link, mode = NG_LINK, 'ng'
    environment = dict(item.split(b'=', 1) for item in (PROC/str(pid)/'environ').read_bytes().split(b'\0')
                       if b'=' in item)
    log('configuration', 'tee.configuration', mode=mode, executable=executable,
        argv0_form='absolute' if argv[0].startswith('/') else 'short', argument_count=len(argv))
    return {'mode': mode, 'link': link, 'original_pid': pid, 'original_executable': executable,
            'original_argv': argv, 'original_env': {name: environment[name.encode()].decode()
                for name in ('LD_LIBRARY_PATH', 'LD_PRELOAD') if name.encode() in environment}}


@contextlib.contextmanager
def factory_keymaster(job):
    settings = configuration()
    link, pid = settings['link'], settings['original_pid']
    if not alive(pid, settings['original_executable']):
        raise ValueError('无法确认当前原生 TEE 进程')
    binary, alias = NATIVE.read_bytes(), None
    if settings['mode'] == 'ng':
        original = b'/mnt/vendor/tee/\0'
        if binary.count(original) != 1:
            raise ValueError('当前 TEE 程序的安全存储路径尚未支持')
        alias = Path('/run/ab' + job.name[-6:])
        if alias.exists() or alias.is_symlink():
            raise ValueError('临时 TEE 路径已占用')
        replacement = (str(alias) + '/').encode() + b'\0'
        if len(replacement) > len(original):
            raise ValueError('临时 TEE 路径过长')
        binary = binary.replace(original, replacement.ljust(len(original), b'\0'))
    private = job / 'tee-supplicant'
    private.write_bytes(binary)
    private.chmod(0o700)
    tas = job/'tas'
    tas.mkdir(mode=0o700)
    keymaster_name = '8efb1e1c-37e5-4326-a5d6-8c33726c7d57.ta'
    for ta in STOCK_TAS.glob('*.ta'):
        if ta.name != keymaster_name:
            (tas/ta.name).symlink_to(ta)
    shutil.copyfile(job/'keymaster.ta', tas/keymaster_name)
    shutil.copyfile(Path(__file__).with_name('bt_tee_restore.py'), job/'tee-restore.py')
    state = {key: settings[key] for key in ('original_pid', 'original_executable', 'original_argv', 'original_env')}
    state.update(ta_link=str(link), original_link=os.readlink(link) if link.is_symlink() else None,
                 store_alias=str(alias) if alias is not None else None)
    atomic(job/'tee-state.json', state)
    timer = 'aurora-bt-tee-' + job.name
    # Independent recovery survives parent/Kodi death. No long-lived daemon.
    run(['systemd-run', '--unit='+timer, '--on-active=240s',
         '--property=Restart=on-failure', '--property=RestartSec=10',
         '/usr/bin/python3', str(job/'tee-restore.py'), str(job)])
    proc = None
    try:
        if alias is not None:
            alias.symlink_to(job/'secure-store')
        with stage('tee.start', '启动临时 TEE 读取环境'):
            os.kill(pid, signal.SIGTERM)
            for _ in range(40):
                if not alive(pid, settings['original_executable']):
                    break
                time.sleep(.1)
            else:
                raise ValueError('原生 TEE 进程未退出')
            temporary = link.with_name(link.name+'.aurora-import')
            temporary.unlink(missing_ok=True)
            temporary.symlink_to(tas)
            temporary.replace(link)
            argv = [str(private)] + (['-f', str(job/'secure-store')] if settings['mode'] == 'no' else [])
            environment = dict(os.environ)
            for name in ('LD_LIBRARY_PATH', 'LD_PRELOAD'):
                environment.pop(name, None)
            proc = subprocess.Popen(argv, env=environment, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, start_new_session=True)
            (job/'private.pid').write_text(str(proc.pid))
            time.sleep(.3)
            if proc.poll() is not None:
                raise ValueError('临时 TEE 读取环境启动失败')
        yield
    finally:
        with stage('tee.restore', '恢复原 TEE 进程与目录'):
            restore(job)
        if proc is not None:
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                pass
        run(['systemctl', 'stop', timer+'.timer'])
