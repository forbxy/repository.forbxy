"""Private RAM jobs and bounded system commands; never log secret arguments."""
import contextlib
import fcntl
import json
import os
from pathlib import Path
import subprocess

BASE = Path('/run/aurora-android-bluetooth')


def run(args, *, data=None, timeout=30):
    try:
        result = subprocess.run([str(x) for x in args], input=data, capture_output=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as error:
        error._bt_command = {'tool': Path(args[0]).name}
        raise
    if result.returncode:
        error = ValueError('系统操作失败：' + Path(args[0]).name)
        error._bt_command = {'tool': Path(args[0]).name, 'returncode': result.returncode}
        raise error
    return result.stdout


def atomic(path, value):
    temporary = path.with_name(path.name + '.new')
    fd = os.open(temporary, os.O_CREAT | os.O_TRUNC | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def job_path(value):
    path = Path(value)
    if (path.parent != BASE or path.resolve() != path or not path.is_dir()
            or path.stat().st_uid != os.geteuid() or path.stat().st_mode & 0o077):
        raise ValueError('无效的蓝牙导入任务')
    return path


@contextlib.contextmanager
def locked():
    # Coordinate with existing eMMC and Logo tasks, including the prepare step.
    with contextlib.ExitStack() as stack:
        for name in ('/run/aurora-android-bluetooth.lock', '/run/aurora-emmc-submit.lock',
                     '/run/aurora-emmc-layout.lock', '/run/aurora-emmc-backup.lock'):
            stream = stack.enter_context(open(name, 'a'))
            try:
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise ValueError('已有蓝牙导入或 eMMC 操作正在进行') from None
        yield
