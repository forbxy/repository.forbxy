"""Independent, idempotent restoration used by parent and watchdog timer."""
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

JOB_BASE = Path('/run/aurora-android-bluetooth')
TA_LINKS = (Path('/var/lib/teetz'), Path('/var/lib/optee_armtz'))
PIDFILE = Path('/run/tee-supplicant.pid')


def alive(pid, executable):
    try:
        return os.readlink('/proc/%d/exe' % pid) == executable
    except OSError:
        return False


def matches(pid, executable, argv):
    if not alive(pid, executable):
        return False
    try:
        actual = [item.decode() for item in Path('/proc', str(pid), 'cmdline').read_bytes().split(b'\0') if item]
        return actual == argv
    except OSError:
        return False


def restore_link(link, original, private):
    current = os.readlink(link) if link.is_symlink() else None
    if (link.exists() and not link.is_symlink()) or current not in (original, private):
        raise ValueError('TEE path changed outside the importer')
    if current != original:
        if original is None:
            link.unlink()
        else:
            temporary = link.with_name(link.name+'.aurora-restore')
            temporary.unlink(missing_ok=True)
            temporary.symlink_to(original)
            temporary.replace(link)


def restore(job):
    job = Path(job)
    if (job.parent != JOB_BASE or job.resolve() != job
            or job.stat().st_uid != 0 or job.stat().st_mode & 0o077):
        raise ValueError('Invalid TEE recovery job')
    with (job / 'tee-restore.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if (job / 'tee-restored').exists():
            return
        state = json.loads((job / 'tee-state.json').read_text())
        private = str(job / 'tee-supplicant')
        pidfile = job / 'private.pid'
        if pidfile.exists():
            pid = int(pidfile.read_text())
            if alive(pid, private):
                os.kill(pid, signal.SIGTERM)
                for _ in range(40):
                    if not alive(pid, private):
                        break
                    time.sleep(.1)
                else:
                    os.kill(pid, signal.SIGKILL)
                    time.sleep(.1)
        link = Path(state.get('ta_link', '/var/lib/teetz'))
        if link not in TA_LINKS:
            raise ValueError('Invalid TEE recovery link')
        restore_link(link, state['original_link'], str(job/'tas'))
        native = state.get('original_executable', '/usr/sbin/tee-supplicant')
        current_pid = PIDFILE
        candidates = [state['original_pid']]
        if current_pid.exists():
            candidates.append(int(current_pid.read_text()))
        if not any(matches(pid, native, state['original_argv']) for pid in candidates):
            environment = dict(os.environ)
            for name in ('LD_LIBRARY_PATH', 'LD_PRELOAD'):
                environment.pop(name, None)
            environment.update(state.get('original_env', {}))
            proc = subprocess.Popen(state['original_argv'], executable=native, env=environment, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, start_new_session=True)
            current_pid.write_text(str(proc.pid) + '\n')
            time.sleep(.5)
            if proc.poll() is not None or not matches(proc.pid, native, state['original_argv']):
                raise RuntimeError('Original TEE supplicant did not restart')
        if state.get('store_alias'):
            alias = Path(state['store_alias'])
            if alias.is_symlink() and os.readlink(alias) == str(job/'secure-store'):
                alias.unlink()
        (job / 'tee-restored').write_text('ok')


if __name__ == '__main__':
    try:
        restore(sys.argv[1])
    except Exception:
        print('TEE 恢复未完成，请保留任务目录并重新运行恢复操作。', file=sys.stderr)
        raise SystemExit(1)
