"""Android 11 Bluedroid -> BlueZ bonds. No device-name or fixed-MAC rules.

Layouts: AOSP system/bt Android 11, btm_api_types.h and btif_storage.cc.
Key octets keep their original order; only numeric Rand/EDiv are decoded LE.
LENC is a local reproduction record, not a peer PENC record.
"""
import configparser
import io
import re
import struct
import uuid

MAC = re.compile(r'(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\Z')
KEY_GROUPS = ('LinkKey', 'LongTermKey', 'IdentityResolvingKey',
              'LocalSignatureKey', 'RemoteSignatureKey')


def ini(text):
    result = configparser.ConfigParser(interpolation=None, strict=True)
    result.optionxform = str
    try:
        result.read_string(text)
    except (configparser.Error, ValueError):
        raise ValueError('蓝牙配对配置格式无效') from None
    return result


def render(conf):
    stream = io.StringIO()
    conf.write(stream, space_around_delimiters=False)
    return stream.getvalue()


def mac(value):
    if not isinstance(value, str) or not MAC.fullmatch(value):
        raise ValueError('蓝牙地址格式无效')
    result = value.upper()
    if result in ('00:00:00:00:00:00', 'FF:FF:FF:FF:FF:FF'):
        raise ValueError('蓝牙地址无效')
    return result


def octets(value, length):
    if not isinstance(value, str) or not re.fullmatch('[0-9a-fA-F]{%d}' % (length*2), value):
        raise ValueError('配对密钥长度或编码无效')
    result = bytes.fromhex(value)
    if not any(result) or result == b'\xff' * length:
        raise ValueError('配对密钥无效')
    return result


def number(value, minimum, maximum):
    try:
        result = int(value, 10)
    except (TypeError, ValueError):
        raise ValueError('配对参数无效') from None
    if not minimum <= result <= maximum:
        raise ValueError('配对参数超出范围')
    return result


def services(value):
    result = set()
    for part in re.split(r'[\s,;]+', value.strip()):
        if not part:
            continue
        if re.fullmatch('[0-9a-fA-F]{4}|[0-9a-fA-F]{8}', part):
            part = part.zfill(8) + '-0000-1000-8000-00805f9b34fb'
        try:
            result.add(str(uuid.UUID(part)))
        except ValueError:
            raise ValueError('设备服务 UUID 无效') from None
    return sorted(result)


def convert(section, row):
    peer = mac(section)
    kind = number(row.get('DevType', '3' if row.get('LinkKey') and row.get('LE_KEY_PENC')
                          else '1' if row.get('LinkKey') else '2'), 1, 3)
    classic = kind in (1, 3) and bool(row.get('LinkKey'))
    le = kind in (2, 3) and bool(row.get('LE_KEY_PENC'))
    if not classic and not le:
        raise ValueError('没有可迁移的长期配对密钥')
    conf = configparser.ConfigParser(interpolation=None)
    conf.optionxform = str
    address_type = 'public'
    if le:
        penc = octets(row['LE_KEY_PENC'], 28)
        ltk, rand, ediv, security, size = struct.unpack('<16sQHBB', penc)
        octets(ltk.hex(), 16)
        if security not in (1, 4) or not 7 <= size <= 16:
            raise ValueError('不支持的 BLE 安全属性')
        if row.get('LE_KEY_PID'):
            pid = octets(row['LE_KEY_PID'], 23)
            peer = mac(':'.join('%02X' % value for value in pid[17:23]))
            addr_type = number(str(pid[16]), 0, 1)
            # Android can persist PID's stable public/static identity with an
            # empty optional IRK (observed on V12, R22 and CMCC). The peer LTK
            # remains usable. Do not install a zero resolving key in BlueZ.
            if any(pid[:16]):
                irk = octets(pid[:16].hex(), 16)
                conf['IdentityResolvingKey'] = {'Key': irk.hex().upper()}
        else:
            addr_type = number(row.get('AddrType', '0'), 0, 1)
        if addr_type:
            if int(peer[:2], 16) & 0xc0 != 0xc0:
                raise ValueError('BLE 随机地址缺少有效的静态身份')
            address_type = 'static'
        if classic and address_type != 'public':
            raise ValueError('双模设备的身份地址不一致')
        if classic and peer != mac(section):
            raise ValueError('双模设备的经典与 BLE 身份地址不一致')
        conf['LongTermKey'] = {'Key': ltk.hex().upper(), 'Authenticated': str(int(security == 4)),
                              'EncSize': str(size), 'EDiv': str(ediv), 'Rand': str(rand)}
        for field, group in (('LE_KEY_PCSRK', 'RemoteSignatureKey'), ('LE_KEY_LCSRK', 'LocalSignatureKey')):
            if row.get(field):
                signed = octets(row[field], 24)
                if signed[20] not in (1, 4):
                    raise ValueError('不支持的 BLE 签名安全属性')
                conf[group] = {'Key': octets(signed[4:20].hex(), 16).hex().upper(),
                               'Counter': str(struct.unpack_from('<I', signed)[0]),
                               'Authenticated': 'true' if signed[20] == 4 else 'false'}
    if classic:
        key = octets(row['LinkKey'], 16)
        conf['LinkKey'] = {'Key': key.hex().upper(),
                          'Type': str(number(row.get('LinkKeyType'), 0, 8)),
                          'PINLength': str(number(row.get('PinLength', '0'), 0, 16))}
    name = row.get('Name', peer).strip()
    if not name or len(name) > 248 or any(ord(c) < 32 or c == '\x7f' for c in name):
        name = peer
    general = {'Name': name.replace('\\', '\\\\'), 'AddressType': address_type, 'Trusted': 'true', 'Blocked': 'false',
               'SupportedTechnologies': ('BR/EDR;' if classic else '') + ('LE;' if le else '')}
    uuids = services(row.get('Service', ''))
    if uuids:
        general['Services'] = ';'.join(uuids) + ';'
    if classic and row.get('DevClass'):
        general['Class'] = '0x%06x' % number(row['DevClass'], 0, 0xffffff)
    # Keep General first for readable native files; no key is included in summaries.
    out = configparser.ConfigParser(interpolation=None)
    out.optionxform = str
    out['General'] = general
    for group in conf.sections():
        out[group] = dict(conf[group])
    return {'peer': peer, 'source_address': mac(section), 'name': name,
            'technology': 'BR/EDR + LE' if classic and le else 'LE' if le else 'BR/EDR',
            'info': render(out)}


def parse_android(text):
    conf = ini(text)
    host = mac(conf.get('Adapter', 'Address', fallback=''))
    converted, skipped, seen, duplicates = [], [], set(), set()
    for section in conf.sections():
        if not MAC.fullmatch(section):
            continue
        row = dict(conf[section])
        try:
            record = convert(section, row)
            if record['peer'] in seen:
                duplicates.add(record['peer'])
                raise ValueError('重复的蓝牙身份地址，无法自动选择认证')
            seen.add(record['peer'])
        except ValueError as error:
            name = row.get('Name', section).strip()
            if not name or len(name) > 248 or any(ord(c) < 32 or c == '\x7f' for c in name):
                name = section.upper()
            skipped.append({'peer': section.upper(), 'name': name, 'reason': str(error)})
        else:
            converted.append(record)
    for record in list(converted):
        if record['peer'] in duplicates:
            converted.remove(record)
            skipped.append({'peer': record['source_address'], 'name': record['name'],
                            'reason': '重复的蓝牙身份地址，无法自动选择认证'})
    return {'host': host, 'records': converted, 'skipped': skipped,
            'saved_peer_count': len(converted) + len(skipped)}


def merged_info(existing, imported):
    """Android auth wins; preserve CE-only metadata, alias and other transports."""
    source = ini(imported)
    target = ini(existing) if existing is not None else ini('')
    if not target.has_section('General'):
        target.add_section('General')
    for key, value in source['General'].items():
        if key in ('Services', 'SupportedTechnologies'):
            values = set(filter(None, value.split(';')))
            values.update(filter(None, target.get('General', key, fallback='').split(';')))
            value = ';'.join(sorted(values)) + ';'
        if key in ('Trusted', 'Blocked') and target.has_option('General', key):
            continue
        target['General'][key] = value
    for section in KEY_GROUPS:
        if source.has_section(section):
            target[section] = dict(source[section])
        elif source.has_section('LongTermKey') and section != 'LinkKey':
            target.remove_section(section)
    return render(target)


def same_info(left, right):
    if left is None:
        return False
    def normalized(text):
        conf = ini(text)
        result = {section: dict(conf[section]) for section in conf.sections()}
        for key in ('Services', 'SupportedTechnologies'):
            if key in result.get('General', {}):
                result['General'][key] = sorted(filter(None, result['General'][key].split(';')))
        for section in KEY_GROUPS:
            if 'Key' in result.get(section, {}):
                result[section]['Key'] = result[section]['Key'].upper()
        for section in ('LocalSignatureKey', 'RemoteSignatureKey'):
            if 'Authenticated' in result.get(section, {}):
                value = result[section]['Authenticated']
                result[section]['Authenticated'] = {'0': 'false', '1': 'true'}.get(value, value)
        return result
    return normalized(left) == normalized(right)
