"""Structured import stages: never serialize command arguments, buffers or locals."""
import contextlib
import contextvars
import errno
import json
from pathlib import Path
import re
import sys
import time
import traceback

PREFIX = '[Aurora6S][BluetoothImport] '
CURRENT = contextvars.ContextVar('bluetooth_import_stage', default=('worker', '蓝牙导入'))


def clean(value):
    # Keys and wrapped blobs must not survive even an unexpected path/message.
    value = re.sub(r'(?i)[0-9a-f]{32,}', '<redacted>', str(value))
    return ''.join(c if ord(c) >= 32 else ' ' for c in value)[:700]


def log(event, phase, **fields):
    entry = {'event': event, 'stage': phase, **fields}
    try:
        sys.stderr.write(PREFIX + json.dumps(entry, ensure_ascii=True) + '\n')
        sys.stderr.flush()
    except (OSError, ValueError):
        pass  # Diagnostics must not interrupt restoration or cleanup.


def details(error):
    saved = getattr(error, '_bt_diagnostic', None)
    if saved is not None:
        return saved
    phase, label = CURRENT.get()
    value = {'stage': phase, 'label': label, 'exception': type(error).__name__}
    safe_tee_status = (type(error) is RuntimeError and re.fullmatch(
        r'TEE (?:open|clock init|invoke) failed: [0-9a-fA-F]{8}, origin [0-9]+', str(error)))
    if type(error) is ValueError or safe_tee_status:
        value['reason'] = clean(error)
    if isinstance(error, OSError):
        value['errno'] = error.errno
        for field in ('filename', 'filename2'):
            path = getattr(error, field, None)
            if isinstance(path, (str, bytes)):
                value[field] = clean(path)
    # No exception repr, source lines, locals, stdout/stderr or subprocess args.
    value['frames'] = [{'file': Path(frame.filename).name, 'line': frame.lineno, 'function': frame.name}
                       for frame in traceback.extract_tb(error.__traceback__)[-12:]]
    value.update(getattr(error, '_bt_command', {}))
    value.update(getattr(error, '_bt_context', {}))
    error._bt_diagnostic = value
    return value


def failure(error):
    value = details(error)
    if not getattr(error, '_bt_reported', False):
        log('error', value['stage'], **{key: item for key, item in value.items() if key != 'stage'})
        error._bt_reported = True
    return value


@contextlib.contextmanager
def stage(phase, label):
    token = CURRENT.set((phase, label))
    started = time.monotonic()
    log('start', phase, label=label)
    try:
        yield
    except Exception as error:
        if getattr(error, '_bt_diagnostic', None) is None:
            failure(error)
        raise
    else:
        log('ok', phase, label=label, seconds=round(time.monotonic()-started, 3))
    finally:
        CURRENT.reset(token)


def message(error):
    value = details(error)
    summary = value['label'] + '失败'
    if type(error) is ValueError:
        summary += '：' + clean(error)
    else:
        summary += '（%s）' % value['exception']
        if value.get('reason'):
            summary += '：' + value['reason']
    if value.get('errno') is not None:
        code = value['errno']
        summary += '\n错误编号：%s%s' % (code, ' / '+errno.errorcode[code] if code in errno.errorcode else '')
    if value.get('filename'):
        summary += '\n路径：' + value['filename']
    if value['stage'] == 'android.metadata.key' and value.get('errno') == errno.ENOENT:
        summary += '\n未找到安卓元数据密钥目录，请确认安卓已正常初始化；当前固件也可能使用不同的加密布局。'
    if getattr(error, '_bt_cleanup_error', None):
        summary += '\n临时任务清理也未完成，具体原因见日志；请保留现有任务供恢复。'
    return summary + '\n阶段：' + value['stage']
