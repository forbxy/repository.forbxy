/* Complete private inode/directory manifest; filesystem is always read-only. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <linux/fs.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <ext2fs/ext2fs.h>
static void ck(errcode_t e,const char *s) { if(e) {fprintf(stderr,"%s: %s\n",s,error_message(e));exit(1);} }
static void hex(const void *data,size_t n) {const unsigned char *b=data;putchar('"');for(size_t i=0;i<n;i++) printf("%02x",b[i]);putchar('"');}
static int first_attr;
static int attr_cb(char *name,char *value,size_t n,void *p) { (void)p; printf("%s[",first_attr?"":",");first_attr=0;hex(name,strlen(name));putchar(',');hex(value,n);putchar(']');return 0; }
static int first_entry;
static int dir_cb(ext2_ino_t dir,int entry,struct ext2_dir_entry *d,int off,int bs,char *buf,void *p) {
 (void)dir;(void)entry;(void)off;(void)bs;(void)buf;(void)p;
 if(!d->inode)return 0;
 printf("%s[%u,%u,",first_entry?"":",",d->inode,ext2fs_dirent_file_type(d));
 first_entry=0;hex(d->name,ext2fs_dirent_name_len(d));putchar(']');return 0;
}
static uint64_t logical,physical,length; static int first_block;
static void flush_block(void) {if(length) {printf("%s[%llu,%llu,%llu]",first_block?"":",",(unsigned long long)logical,(unsigned long long)physical,(unsigned long long)length);first_block=0;length=0;}}
static int block_cb(ext2_filsys fs,blk64_t *b,e2_blkcnt_t l,blk64_t ref,int off,void *p) {
 (void)fs;(void)ref;(void)off;(void)p;
 if(l<0 || !*b)return 0;
 if(length && logical+length==(uint64_t)l && physical+length==*b)length++;
 else {flush_block();logical=l;physical=*b;length=1;}return 0;
}
int main(int argc,char **argv) {
 if(argc!=2)return 2;
 struct stat st;int fd=open(argv[1],O_RDONLY),ro=0;
 if(fd<0 || fstat(fd,&st))return 2;
 if(S_ISBLK(st.st_mode)) {if(ioctl(fd,BLKROGET,&ro)||ro!=1)return 2;}
 else if(!S_ISREG(st.st_mode)||strncmp(argv[1],"/storage/aurora-emmc-staging/",sizeof("/storage/aurora-emmc-staging/")-1))return 2;
 close(fd);initialize_ext2_error_table();ext2_filsys fs;ck(ext2fs_open(argv[1],EXT2_FLAG_64BITS,0,0,unix_io_manager,&fs),"open");ck(ext2fs_read_bitmaps(fs),"bitmaps");
 printf("{\"super\":{\"block_size\":%u,\"block_count\":%llu,\"uuid\":",fs->blocksize,(unsigned long long)ext2fs_blocks_count(fs->super));
 hex(fs->super->s_uuid,16);
 printf(",\"first_inode\":%u,\"quota_inodes\":[%u,%u,%u],\"journal_inode\":%u,\"features\":[%u,%u,%u],\"encoding\":%u,\"encoding_flags\":%u}}\n",fs->super->s_first_ino,fs->super->s_usr_quota_inum,fs->super->s_grp_quota_inum,fs->super->s_prj_quota_inum,fs->super->s_journal_inum,fs->super->s_feature_compat,fs->super->s_feature_incompat,fs->super->s_feature_ro_compat,fs->super->s_encoding,fs->super->s_encoding_flags);
 for(ext2_ino_t ino=1;ino<=fs->super->s_inodes_count;ino++) {
  if(!ext2fs_test_inode_bitmap2(fs->inode_map,ino))continue;
  struct ext2_inode_large i; memset(&i,0,sizeof(i));ck(ext2fs_read_inode_full(fs,ino,(struct ext2_inode*)&i,sizeof(i)),"inode");
  if(!i.i_mode)continue;
  struct ext2_xattr_handle *h;ck(ext2fs_xattrs_open(fs,ino,&h),"attr_open");ck(ext2fs_xattrs_read(h),"attrs");
  printf("{\"inode\":%u",ino);
  printf(",\"mode\":%u,\"uid\":%u,\"gid\":%u,\"uid_hi\":%u,\"gid_hi\":%u,\"links\":%u,\"flags\":%u,\"size\":%llu,\"generation\":%u,\"atime\":%u,\"ctime\":%u,\"mtime\":%u,\"crtime\":%u,\"attrs\":[",i.i_mode,i.i_uid,i.i_gid,i.osd2.linux2.l_i_uid_high,i.osd2.linux2.l_i_gid_high,i.i_links_count,i.i_flags,(unsigned long long)EXT2_I_SIZE((struct ext2_inode*)&i),i.i_generation,i.i_atime,i.i_ctime,i.i_mtime,i.i_crtime);
  first_attr=1;ck(ext2fs_xattrs_iterate(h,attr_cb,NULL),"attriterate");ext2fs_xattrs_close(&h);printf("],\"blocks\":[");
  first_block=1;length=0;if(LINUX_S_ISREG(i.i_mode) || (LINUX_S_ISLNK(i.i_mode) && !ext2fs_is_fast_symlink((struct ext2_inode*)&i)))ck(ext2fs_block_iterate3(fs,ino,BLOCK_FLAG_READ_ONLY,NULL,block_cb,NULL),"blocks");flush_block();printf("],\"entries\":[");
  first_entry=1;if(LINUX_S_ISDIR(i.i_mode))ck(ext2fs_dir_iterate2(fs,ino,0,NULL,dir_cb,NULL),"directory");
  printf("],\"fast_symlink\":");
  if(LINUX_S_ISLNK(i.i_mode) && ext2fs_is_fast_symlink((struct ext2_inode*)&i)) {
   if(i.i_size>sizeof(i.i_block)) {fprintf(stderr,"Fast symlink too long\n");return 3;}
   hex(i.i_block,i.i_size);
  } else printf("null");
  printf(",\"project_id\":%u,\"atime_extra\":%u,\"ctime_extra\":%u,\"mtime_extra\":%u,\"crtime_extra\":%u,\"extents\":[",i.i_projid,i.i_atime_extra,i.i_ctime_extra,i.i_mtime_extra,i.i_crtime_extra);
  int first_extent=1;
  if((i.i_flags&EXT4_EXTENTS_FL) && (LINUX_S_ISREG(i.i_mode)||LINUX_S_ISLNK(i.i_mode))) {
   ext2_extent_handle_t eh;struct ext2fs_extent e;ck(ext2fs_extent_open(fs,ino,&eh),"extent_open");
   errcode_t err=ext2fs_extent_get(eh,EXT2_EXTENT_ROOT,&e);
   while(!err) {
    if((e.e_flags&EXT2_EXTENT_FLAGS_LEAF) && !(e.e_flags&EXT2_EXTENT_FLAGS_SECOND_VISIT)) {
     printf("%s[%llu,%llu,%u,%u]",first_extent?"":",",(unsigned long long)e.e_lblk,(unsigned long long)e.e_pblk,e.e_len,e.e_flags&EXT2_EXTENT_FLAGS_UNINIT);first_extent=0;
    }
    err=ext2fs_extent_get(eh,EXT2_EXTENT_NEXT,&e);
   }
   if(err!=EXT2_ET_EXTENT_NO_NEXT && err!=EXT2_ET_NO_CURRENT_NODE)ck(err,"extents");
   ext2fs_extent_free(eh);
  }
  printf("]}\n");
 }
 ck(ext2fs_close(fs),"close");return 0;
}
