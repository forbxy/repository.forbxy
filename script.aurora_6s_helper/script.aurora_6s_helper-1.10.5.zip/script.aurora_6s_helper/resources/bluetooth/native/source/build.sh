#!/bin/sh
# Rebuild using an aarch64 cross compiler and its static libc/sysroot.
# AURORA_BT_CC may name a compiler wrapper when a custom sysroot is required.
# A new toolchain can change the hash: update provenance and bt_android.py
# after validating a rebuilt binary. Runtime hash checks are never disabled.
set -eu
aurora_source_dir=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
aurora_work_dir=${1:?Usage: build.sh /absolute/empty/work-directory}
case "$aurora_work_dir" in /*) ;; *) exit 2 ;; esac
mkdir -p "$aurora_work_dir"
test -z "$(ls -A "$aurora_work_dir")"
aurora_cc=${AURORA_BT_CC:-aarch64-linux-gnu-gcc}
printf '%s  %s\n' fd5bf388cbdbe006a3d3b318d983b2948382440acc85a87f1e7d108653e8db0b "$aurora_source_dir/e2fsprogs-1.47.4.tar.xz" | sha256sum -c -
tar -xf "$aurora_source_dir/e2fsprogs-1.47.4.tar.xz" -C "$aurora_work_dir"
mkdir "$aurora_work_dir/build"
cd "$aurora_work_dir/build"
CC="$aurora_cc" CFLAGS=-O2 LDFLAGS=-static ../e2fsprogs-1.47.4/configure \
    --host=aarch64-linux-gnu --enable-libuuid --enable-libblkid \
    --disable-elf-shlibs --disable-nls --disable-fuse2fs --disable-uuidd
make -j2 libs
"$aurora_cc" -O2 -static -I../e2fsprogs-1.47.4/lib -Ilib \
    "$aurora_source_dir/full_manifest.c" -Wl,--start-group \
    lib/libext2fs.a lib/libblkid.a lib/libcom_err.a lib/libuuid.a \
    -Wl,--end-group -lpthread -o "$aurora_work_dir/full-manifest"
sha256sum "$aurora_work_dir/full-manifest"
