"""Minimal factory Keymaster transport. Explicit allowed commands, no key management writes."""
import os,fcntl,struct,ctypes,uuid,mmap,time
class Keymaster:
 def __init__(self):
  self.fd=os.open('/dev/tee0',os.O_RDWR);self.session=None;self.memory=None;self.shmfd=None
  try:
   buf=bytearray(struct.pack('<16s16sIIIIII',uuid.UUID('8efb1e1c-37e5-4326-a5d6-8c33726c7d57').bytes,b'\0'*16,0,0,0,0,0,0))
   self.ioctl_buf(2,buf);v=struct.unpack('<16s16sIIIIII',buf)
   if v[5]:raise RuntimeError(f'TEE open failed: {v[5]:08x}, origin {v[6]}')
   self.session=v[4]
   shm=bytearray(struct.pack('<QIi',16384,0,0));self.shmfd=fcntl.ioctl(self.fd,0xc010a401,shm,True)
   self.shmid=struct.unpack('<QIi',shm)[2];self.memory=mmap.mmap(self.shmfd,16384)
  except: self.close();raise
 def ioctl_buf(self,n,buf):
  mem=(ctypes.c_char*len(buf)).from_buffer(buf)
  fcntl.ioctl(self.fd,0x8010a400+n,struct.pack('<QQ',ctypes.addressof(mem),len(buf)))
 def initialize_clock(self):
  tick=int(time.clock_gettime(time.CLOCK_BOOTTIME)*1000)
  params=struct.pack('<QQQQ',1,tick>>32,tick&0xffffffff,0)+b'\0'*96
  buf=bytearray(struct.pack('<IIIIII',0x40000,self.session,0,0,0,4)+params)
  self.ioctl_buf(3,buf);v=struct.unpack_from('<IIIIII',buf)
  if v[3]:raise RuntimeError(f'TEE clock init failed: {v[3]:08x}, origin {v[4]}')
 def call(self,command,payload=b''):
  # Version, characteristics, volatile version Configure, decrypt operation, abort only.
  if command not in (0x1c,0x3c,0x48,0x04,0x08,0x0c,0x10):raise ValueError('Command not allowed')
  if len(payload)>4096:raise ValueError('Oversized request')
  self.memory[:]=b'\0'*16384;self.memory[:len(payload)]=payload
  params=struct.pack('<QQQQ',5,0,len(payload),self.shmid)+struct.pack('<QQQQ',6,8192,8192,self.shmid)+struct.pack('<QQQQ',2,0,0,0)+b'\0'*32
  buf=bytearray(struct.pack('<IIIIII',command,self.session,0,0,0,4)+params)
  self.ioctl_buf(3,buf);v=struct.unpack_from('<IIIIII',buf)
  if v[3]:raise RuntimeError(f'TEE invoke failed: {v[3]:08x}, origin {v[4]}')
  p2=struct.unpack_from('<QQQQ',buf,24+64);n=p2[2]
  if n>8188:raise ValueError('Oversized response')
  return bytes(self.memory[8192:8192+n+4])
 def close(self):
  if self.memory is not None:self.memory[:]=b'\0'*16384;self.memory.close();self.memory=None
  if self.shmfd is not None:os.close(self.shmfd);self.shmfd=None
  if self.session is not None:fcntl.ioctl(self.fd,0x8004a405,struct.pack('<I',self.session));self.session=None
  if self.fd is not None:os.close(self.fd);self.fd=None
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
