"""Factory Android 11 decrypt operations, adapted from the 6 Pro research."""
import struct, hashlib
from bt_keymaster import Keymaster

def blob(value):
    return struct.pack('<I',len(value))+value


def authset(items):
    indirect = b''; elements = b''
    for tag,value in items:
        elements += struct.pack('<I',tag)
        if tag>>28 in (8,9):
            elements += struct.pack('<II',len(value),len(indirect)); indirect += value
        else:
            elements += struct.pack('<I',value)
    return blob(indirect)+struct.pack('<II',len(items),len(elements))+elements


def response(client, command, request):
    data = client.call(command,request)
    if len(data)<8 or struct.unpack_from('<I',data)[0] != command|1:
        raise ValueError('Invalid Keymaster response header')
    error = struct.unpack_from('<i',data,4)[0]
    if error:
        raise ValueError('Factory Keymaster rejected command '+hex(command)+': '+str(error))
    return data[8:]


def unwrap_key(folder, props):
    read = folder.__getitem__ if isinstance(folder,dict) else lambda name:(folder/name).read_bytes()
    if read('version')!=b'1' or read('stretching')!=b'nopassword':
        raise ValueError('Unsupported metadata key wrapping format')
    encrypted = read('encrypted_key')
    wrapped = read('keymaster_key_blob')
    discardable = read('secdiscardable')
    if len(encrypted)!=92 or not wrapped or len(discardable)!=16384:
        raise ValueError('Unsupported metadata key record lengths')
    version = [int(part) for part in props['ro.build.version.release'].split('.')]
    version = (version+[0,0])[:3]
    os_version = version[0]*10000+version[1]*100+version[2]
    patch = int(props['ro.build.version.security_patch'][:7].replace('-',''))
    app_id = hashlib.sha512(b'Android secdiscardable SHA512'.ljust(128,b'\0')+discardable).digest()
    params = authset([(0x20000004,32),(0x20000006,1),(0x300003eb,128),
                      (0x90000259,app_id),(0x900003e9,encrypted[:12])])
    with Keymaster() as client:
        client.initialize_clock()
        response(client,0x48,struct.pack('<II',os_version,patch))
        body = response(client,0x04,struct.pack('<I',1)+blob(wrapped)+params)
        if len(body)<8: raise ValueError('Missing Keymaster operation handle')
        handle = body[:8]
        try:
            body = response(client,0x0c,handle+blob(b'')+authset([])+blob(encrypted[12:]))
            length = struct.unpack_from('<I',body)[0]
            if length!=64 or len(body)<68:
                raise ValueError('Unexpected unwrapped metadata key length')
            return bytearray(body[4:68])
        finally:
            try: response(client,0x10,handle)
            except ValueError: pass  # FINISH already consumed the operation.
