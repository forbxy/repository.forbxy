"""Explicit Android bond import from the helper's menu; no startup integration."""
import json
import os
from pathlib import Path
import subprocess

import xbmc
import xbmcgui

WORKER = Path(__file__).resolve().parents[1]/'bluetooth/bt_worker.py'
TITLE = '导入安卓蓝牙配对'
LOG_PREFIX = '[Aurora6S][BluetoothImport] '


def log_worker(result):
    found = False
    for line in result.stderr.splitlines():
        if not line.startswith(LOG_PREFIX):
            continue
        try:
            entry = json.loads(line[len(LOG_PREFIX):])
        except (TypeError, ValueError):
            continue
        if not isinstance(entry, dict):
            continue
        found = True
        level = xbmc.LOGERROR if entry.get('event') == 'error' else xbmc.LOGINFO
        xbmc.log(LOG_PREFIX + json.dumps(entry, ensure_ascii=False), level)
    if result.returncode and not found:
        xbmc.log(LOG_PREFIX + '工作进程未返回阶段诊断，退出码：%s' % result.returncode, xbmc.LOGERROR)


def call(*args):
    result = subprocess.run(['/usr/bin/python3', str(WORKER), *map(str, args)],
                            capture_output=True, text=True, encoding='utf-8', errors='replace',
                            env={**os.environ, 'PYTHONIOENCODING': 'utf-8', 'PYTHONUTF8': '1'})
    log_worker(result)
    try:
        value = json.loads(result.stdout)
    except (TypeError, ValueError):
        xbmc.log(LOG_PREFIX + '工作进程响应格式无效，退出码：%s' % result.returncode, xbmc.LOGERROR)
        raise ValueError('蓝牙工作进程响应无效（退出码 %s），请查看 Kodi 日志。' % result.returncode) from None
    if not isinstance(value, dict):
        raise ValueError('蓝牙工作进程响应格式无效，请查看 Kodi 日志。')
    if result.returncode or value.get('error'):
        raise ValueError(value.get('error', '蓝牙配对导入未完成。'))
    return value


def main():
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, '正在读取安卓已保存的配对，请稍候…')
    job = None
    try:
        try:
            plan = call('prepare')
            job = plan['job']
        finally:
            progress.close()
        devices = plan['devices']
        skipped = plan['skipped']
        def skip_reason(item):
            return '%s（%s）：%s' % (item.get('name', item['peer']), item['peer'], item['reason'])
        if not devices:
            reasons = '\n'.join(skip_reason(item) for item in skipped)
            dialog.ok(TITLE, '未发现可导入的安卓配对。' + ('\n'+reasons if reasons else ''))
            return
        labels = {'add': '新增', 'replace': '覆盖 CE 认证', 'unchanged': '已一致'}
        rows = ['%s（%s）\n%s · %s' % (item['name'], item['peer'], item['technology'], labels[item['action']])
                for item in devices]
        rows += ['[无法导入] '+skip_reason(item) for item in skipped]
        selected = dialog.multiselect('选择要导入的设备（确认后自动覆盖）', rows,
                                      preselect=list(range(len(devices))))
        if not selected:
            return
        unavailable = [skipped[index-len(devices)] for index in selected if index >= len(devices)]
        selected = [index for index in selected if index < len(devices)]
        if unavailable:
            dialog.ok('以下记录无法导入', '\n'.join(skip_reason(item) for item in unavailable))
        if not selected:
            return
        progress = xbmcgui.DialogProgressBG()
        progress.create(TITLE, '正在备份并导入；蓝牙连接可能短暂断开…')
        try:
            peers = json.dumps([devices[index]['peer'] for index in selected])
            result = call('apply', job, '--peers', peers, '--confirm')
            job = None  # Successful apply has already removed private RAM material.
        finally:
            progress.close()
        message = '已导入 %d 个，已有认证一致 %d 个。' % (result['imported'], result['unchanged'])
        if plan['skipped']:
            message += '\n跳过 %d 个不支持或缺少认证的记录。' % len(plan['skipped'])
        if result.get('backup'):
            message += '\n覆盖前备份：' + result['backup']
        message += '\n请重启系统使配对信息生效，重启后再轻按设备按键唤醒并测试连接。'
        dialog.ok(TITLE, message)
    finally:
        if job:
            call('discard', job)
