#!/usr/bin/env python3
"""User-invoked pairing import. No boot hook, reconnect or background daemon."""
import argparse
import configparser
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

from bt_pairing import mac, merged_info, same_info
from bt_support import BASE, atomic, job_path, locked, run

STORAGE = Path('/storage/.cache/bluetooth')
BACKUPS = Path('/storage/.cache/aurora-android-bluetooth/backups')
ROOT = Path(__file__).resolve().parent


def boot_id():
    return Path('/proc/sys/kernel/random/boot_id').read_text().strip()


def real_directory(path):
    if path.resolve() != path or path.is_symlink() or not path.is_dir():
        raise ValueError('蓝牙数据目录不可通过符号链接重定向')


def check_tree(path):
    if not path.exists() and not path.is_symlink():
        return
    if path.is_symlink() or not (path.is_dir() or path.is_file()):
        raise ValueError('蓝牙配对文件类型异常')
    if path.is_dir():
        for child in path.rglob('*'):
            if child.is_symlink() or not (child.is_dir() or child.is_file()):
                raise ValueError('蓝牙配对目录含异常文件')


def adapter_present(host):
    output = run(['bluetoothctl', 'list']).decode(errors='replace')
    addresses = re.findall(r'^Controller ((?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2})\b', output, re.MULTILINE)
    if sum(value.upper() == host for value in addresses) != 1:
        raise ValueError('安卓与 CE 蓝牙主机地址不匹配，请先确认使用同一个板载适配器')


def operations(payload):
    host = mac(payload['host'])
    real_directory(STORAGE)
    directory = STORAGE/host
    real_directory(directory)
    result = []
    for record in payload['records']:
        peer = mac(record['peer'])
        target, cache = directory/peer, directory/'cache'/peer
        check_tree(target)
        check_tree(cache)
        if (directory/'cache').exists():
            real_directory(directory/'cache')
        path = target/'info'
        before = path.read_text(encoding='utf-8') if path.is_file() else None
        try:
            content = merged_info(before, record['info'])
            same = same_info(before, content)
        except ValueError:
            # The selected Android bond is authoritative even for malformed CE info.
            content, same = merged_info(None, record['info']), False
        result.append({'peer': peer, 'name': record['name'], 'technology': record['technology'],
                       'action': 'unchanged' if same else 'replace' if before is not None else 'add',
                       'content': content})
    return result


def public_entries(entries):
    return [{key: value for key, value in entry.items() if key != 'content'} for entry in entries]


def cleanup_secrets(job):
    # Keep only the prepared bond and public plan. Factory decryption material
    # and the full filesystem metadata index are never persistent artifacts.
    if (job/'tee-state.json').exists() and not (job/'tee-restored').exists():
        raise ValueError('TEE 恢复尚未完成，已保留 RAM 任务供恢复')
    for path in list(job.iterdir()):
        if path.name in ('records.json', 'plan.json', 'tee-state.json', 'tee-restored',
                         'tee-restore.py', 'tee-restore.lock', 'private.pid', 'runtime'):
            continue
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()


def discard(value):
    job = job_path(value)
    if (job/'tee-state.json').exists() and not (job/'tee-restored').exists():
        from bt_tee_restore import restore
        restore(job)
    # Expiry timer is a bounded cleanup task, never a startup service.
    subprocess.run(['systemctl', 'stop', 'aurora-bt-expire-'+job.name+'.timer'],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
    shutil.rmtree(job)


def prepare():
    from bt_android import acquire
    BASE.mkdir(mode=0o700, parents=True, exist_ok=True)
    real_directory(BASE)
    if BASE.stat().st_mode & 0o077:
        raise ValueError('RAM 工作目录权限异常')
    # Recover an interrupted read before beginning another private TEE session.
    for previous in BASE.iterdir():
        if previous.is_dir() and (previous/'tee-state.json').exists() and not (previous/'tee-restored').exists():
            from bt_tee_restore import restore
            restore(job_path(previous))
    job = Path(tempfile.mkdtemp(prefix=uuid.uuid4().hex[:12]+'-', dir=BASE))
    try:
        # Expiry is armed before any secret acquisition, also covering failures.
        runtime = job/'runtime'
        runtime.mkdir(mode=0o700)
        for name in ('bt_worker.py', 'bt_pairing.py', 'bt_support.py', 'bt_tee_restore.py'):
            shutil.copyfile(ROOT/name, runtime/name)
        run(['systemd-run', '--unit=aurora-bt-expire-'+job.name, '--on-active=15m',
             '/usr/bin/python3', runtime/'bt_worker.py', 'expire', job])
        payload = acquire(job)
        adapter_present(payload['host'])
        entries = operations(payload)
        atomic(job/'records.json', payload)
        plan = {'job': str(job), 'boot_id': boot_id(), 'created_unix': time.time(),
                'host': payload['host'], 'model': payload['model'], 'branch': payload['branch'],
                'source': payload['source'], 'devices': public_entries(entries),
                'skipped': payload['skipped'], 'saved_peer_count': payload['saved_peer_count'],
                'android_unchanged': payload['android_unchanged'], 'tee_restored': payload['tee_restored']}
        atomic(job/'plan.json', plan)
        cleanup_secrets(job)
        return plan
    except Exception:
        if not (job/'tee-state.json').exists() or (job/'tee-restored').exists():
            discard(job)
        raise


def service_active(unit):
    result = subprocess.run(['systemctl', 'show', unit, '--property=ActiveState,LoadState'],
                            capture_output=True, text=True, timeout=10)
    fields = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
    if fields.get('LoadState') == 'not-found' and unit == 'gremote-reconnect.service':
        return False
    if result.returncode:
        raise ValueError('无法读取蓝牙相关服务状态')
    state = fields.get('ActiveState')
    if state not in ('active', 'inactive', 'failed'):
        raise ValueError('蓝牙相关服务正在切换状态，请稍后重试')
    return state == 'active'


def write_info(path, content):
    path.parent.mkdir(mode=0o700, exist_ok=True)
    temporary = path.with_name('info.aurora-new')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def snapshot(directory, entries, backup):
    manifest = []
    for entry in entries:
        peer = entry['peer']
        target, cache = directory/peer, directory/'cache'/peer
        check_tree(target)
        check_tree(cache)
        saved = backup/peer
        saved.mkdir(mode=0o700)
        if target.exists():
            shutil.copytree(target, saved/'device')
        if cache.is_file():
            shutil.copyfile(cache, saved/'cache')
        manifest.append({'peer': peer, 'device_existed': target.exists(), 'cache_existed': cache.exists()})
    atomic(backup/'manifest.json', {'host': directory.name, 'devices': manifest, 'status': 'backed_up'})
    return manifest


def restore_snapshot(directory, manifest, backup):
    for item in manifest:
        target, cache = directory/item['peer'], directory/'cache'/item['peer']
        check_tree(target)
        check_tree(cache)
        if target.exists():
            shutil.rmtree(target)
        if item['device_existed']:
            shutil.copytree(backup/item['peer']/'device', target)
        cache.unlink(missing_ok=True)
        if item['cache_existed']:
            cache.parent.mkdir(mode=0o700, exist_ok=True)
            shutil.copyfile(backup/item['peer']/'cache', cache)


def apply(value, peers=None):
    job = job_path(value)
    plan = json.loads((job/'plan.json').read_text())
    if plan['boot_id'] != boot_id() or not 0 <= time.time()-plan['created_unix'] < 900:
        raise ValueError('读取结果已过期，请重新读取安卓配对')
    payload = json.loads((job/'records.json').read_text())
    adapter_present(payload['host'])
    available = {record['peer'] for record in payload['records']}
    selected = available if peers is None else {mac(peer) for peer in peers}
    if not selected or not selected <= available:
        raise ValueError('未选择有效的安卓配对设备')
    payload['records'] = [record for record in payload['records'] if record['peer'] in selected]
    entries = operations(payload)
    changes = [entry for entry in entries if entry['action'] != 'unchanged']
    if not changes:
        return {'imported': 0, 'unchanged': len(entries), 'devices': public_entries(entries),
                'bluetooth_restarted': False, 'backup': None}
    BACKUPS.mkdir(mode=0o700, parents=True, exist_ok=True)
    real_directory(BACKUPS)
    BACKUPS.chmod(0o700)
    backup = BACKUPS/(time.strftime('%Y%m%d-%H%M%S-')+uuid.uuid4().hex[:8])
    backup.mkdir(mode=0o700)
    native_active = service_active('bluetooth.service')
    # Respect the user's existing helper state. Never enable/start a stopped helper.
    helper_active = service_active('gremote-reconnect.service')
    manifest = None
    directory = STORAGE/payload['host']
    try:
        if helper_active:
            run(['systemctl', 'stop', 'gremote-reconnect.service'], timeout=40)
        if native_active:
            run(['systemctl', 'stop', 'bluetooth.service'], timeout=40)
        # Read native files after bluetoothd has flushed its latest state.
        entries = operations(payload)
        changes = [entry for entry in entries if entry['action'] != 'unchanged']
        manifest = snapshot(directory, changes, backup)
        for entry in changes:
            target = directory/entry['peer']
            write_info(target/'info', entry['content'])
            for stale in (target/'attributes', target/'ccc', directory/'cache'/entry['peer']):
                if stale.exists() and not stale.is_file():
                    raise ValueError('目标设备缓存类型异常')
                stale.unlink(missing_ok=True)
        if native_active:
            run(['systemctl', 'start', 'bluetooth.service'], timeout=40)
        atomic(backup/'manifest.json', {'host': directory.name, 'devices': manifest, 'status': 'imported'})
    except Exception:
        if manifest is not None:
            if native_active:
                run(['systemctl', 'stop', 'bluetooth.service'], timeout=40)
            restore_snapshot(directory, manifest, backup)
            atomic(backup/'manifest.json', {'host': directory.name, 'devices': manifest, 'status': 'rolled_back'})
        raise
    finally:
        if native_active:
            run(['systemctl', 'start', 'bluetooth.service'], timeout=40)
        if helper_active:
            run(['systemctl', 'start', 'gremote-reconnect.service'], timeout=40)
    return {'imported': len(changes), 'unchanged': len(entries)-len(changes),
            'devices': public_entries(entries), 'bluetooth_restarted': native_active,
            'backup': str(backup)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    sub.add_parser('prepare')
    command = sub.add_parser('apply')
    command.add_argument('job')
    command.add_argument('--peers', help='Selected peer addresses as a JSON array; defaults to all')
    command.add_argument('--confirm', action='store_true', required=True)
    for name in ('discard', 'expire'):
        command = sub.add_parser(name)
        command.add_argument('job')
    args = parser.parse_args()
    os.umask(0o077)
    try:
        with locked():
            if args.action == 'prepare':
                result = prepare()
            elif args.action == 'apply':
                peers = json.loads(args.peers) if args.peers is not None else None
                if peers is not None and (not isinstance(peers, list) or not all(isinstance(peer, str) for peer in peers)):
                    raise ValueError('设备选择格式无效')
                result = apply(args.job, peers)
                discard(args.job)
            else:
                # Do not stop the currently executing expiry service itself.
                discard(args.job)
                result = {'discarded': True}
        print(json.dumps(result, ensure_ascii=False))
    except Exception as error:
        message = str(error) if type(error) is ValueError else '蓝牙配对导入未完成，请检查当前系统与任务状态。'
        print(json.dumps({'error': message}, ensure_ascii=False))
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
