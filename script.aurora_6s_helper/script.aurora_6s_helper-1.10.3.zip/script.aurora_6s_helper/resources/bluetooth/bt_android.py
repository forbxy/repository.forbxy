"""Common NG/NO, A4111/A4112 read-only Android 11 pairing acquisition.

Original eMMC is opened read-only. All block aliases are bounded/read-only;
mounts use noload. Factory secure storage is copied into private RAM.
"""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import stat
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'emmc'))
from aurora_emmc import parse_mpt, mountinfo
from block_device import BLKGETSIZE64
from platform_support import branch
from bt_support import run
from bt_lp import metadata_geometry, vendor_extents, validate_vendor_filesystem, parse_active_slot
from bt_tee import factory_keymaster
from bt_unwrap import unwrap_key
from bt_fscrypt import Filesystem, context
from bt_pairing import parse_android

DISK = Path('/dev/mmcblk0')
NATIVE = Path(__file__).parent/'native/full-manifest'
MANIFEST_SHA = 'a8c6dc70d7e09f7eb217f44f8f00a330c5852d36b94c952dfa0098840261a5e2'


def size(path):
    with open(path, 'rb', buffering=0) as stream:
        return struct.unpack('<Q', fcntl.ioctl(stream, BLKGETSIZE64, bytes(8)))[0]


def readonly(path):
    with open(path, 'rb', buffering=0) as stream:
        if struct.unpack('<I', fcntl.ioctl(stream, 0x125e, bytes(4)))[0] != 1:
            raise ValueError('临时块映射不是只读')


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb', buffering=0) as stream:
        for part in iter(lambda: stream.read(1024**2), b''):
            h.update(part)
    return h.hexdigest()


def preflight():
    if os.geteuid() != 0:
        raise ValueError('需要 CoreELEC root 权限')
    release = dict(line.split('=', 1) for line in Path('/etc/os-release').read_text().splitlines()
                   if '=' in line and not line.startswith('#'))
    release = {key: value.strip('"') for key, value in release.items()}
    variant = branch(release)
    mounts = [row for row in mountinfo() if '/run' == row['mountpoint'] or
              '/run'.startswith(row['mountpoint'].rstrip('/')+'/')]
    if not mounts or max(mounts, key=lambda row: len(row['mountpoint']))['fs'] != 'tmpfs':
        raise ValueError('系统 /run 必须为 RAM 临时文件系统')
    if b'amlogic,sc2' not in Path('/proc/device-tree/compatible').read_bytes().replace(b' ', b'').split(b'\0'):
        raise ValueError('仅支持极光 4 Pro / 6S 的 SC2 平台')
    if not stat.S_ISBLK(DISK.stat().st_mode):
        raise ValueError('无法确认内置 eMMC')
    capacity = size(DISK)
    with DISK.open('rb', buffering=0) as stream:
        stream.seek(36*1024**2)
        raw = stream.read(4096)
    rows = parse_mpt(raw, capacity)['partitions']
    parts = {row['name']: row for row in rows}
    if not {'env', 'metadata', 'tee', 'super', 'userdata'} <= set(parts):
        raise ValueError('安卓分区表缺少必要分区')
    if parts['metadata']['size'] != 16*1024**2 or parts['tee']['size'] != 32*1024**2:
        raise ValueError('当前安卓密钥分区布局尚未支持')
    if hashlib.sha256(NATIVE.read_bytes()).hexdigest() != MANIFEST_SHA:
        raise ValueError('只读文件系统工具校验失败')
    for tool in ('dmsetup', 'mount', 'umount', 'losetup', 'fw_printenv', 'systemd-run'):
        if shutil.which(tool) is None:
            raise ValueError('系统缺少必要工具：' + tool)
    memory = dict((line.split(':')[0], int(line.split()[1])*1024)
                  for line in Path('/proc/meminfo').read_text().splitlines() if line.split()[1].isdigit())
    space = os.statvfs('/run')
    if memory.get('MemAvailable', 0) < 256*1024**2 or space.f_bavail*space.f_frsize < 160*1024**2:
        raise ValueError('读取安卓配对至少需要 256 MiB 可用内存和 160 MiB RAM 空间')
    return {'branch': variant, 'parts': parts, 'mpt_sha256': hashlib.sha256(raw).hexdigest(),
            'cid': Path('/sys/block/mmcblk0/device/cid').read_text().strip()}


class Reader:
    def __init__(self, job, identity):
        self.job, self.identity, self.counter = job, identity, 0

    @contextlib.contextmanager
    def mapping(self, table, expected):
        self.counter += 1
        name = 'aurora-bt-%s-%d' % (self.job.name, self.counter)
        path = Path('/dev/mapper')/name
        run(['dmsetup', 'create', name, '--readonly'], data=(table+'\n').encode())
        try:
            readonly(path)
            if size(path) != expected:
                raise ValueError('只读分区映射容量不一致')
            yield path
        finally:
            run(['dmsetup', 'remove', '--retry', name])

    @contextlib.contextmanager
    def region(self, name):
        row = self.identity['parts'][name]
        # A raw-disk dm-linear claim conflicts with NG's open MPT partitions.
        # A bounded read-only loop uses a read-only fd instead of claiming the
        # entire disk. Verify its backing rdev/range before using it on NG/NO.
        path = Path(run(['losetup', '--find', '--show', '--read-only', '--offset',
                         str(row['offset']), '--sizelimit', str(row['size']), DISK]).decode().strip())
        try:
            if not __import__('re').fullmatch(r'/dev/loop[0-9]+', str(path)):
                raise ValueError('只读分区视图无效')
            with path.open('rb', buffering=0) as stream:
                status = fcntl.ioctl(stream, 0x4c05, bytes(232))
                _, _, rdev, offset, limit = struct.unpack_from('=5Q', status)
            if (rdev, offset, limit, size(path)) != (DISK.stat().st_rdev, row['offset'], row['size'], row['size']):
                raise ValueError('只读分区视图的后端或边界不一致')
            readonly(path)
            yield path
        finally:
            run(['losetup', '--detach', path])

    @contextlib.contextmanager
    def mounted(self, path):
        mount = self.job/'mount'
        mount.mkdir(mode=0o700)
        try:
            run(['mount', '-t', 'ext4', '-o', 'ro,noload,nodev,nosuid,noexec', path, mount])
            try:
                yield mount
            finally:
                run(['umount', mount])
        finally:
            mount.rmdir()

    def key_copies(self):
        hashes = {}
        for name in ('metadata', 'tee'):
            with self.region(name) as source:
                hashes[name] = digest(source)
                image = self.job/(name+'.img')
                with source.open('rb', buffering=0) as stream, image.open('xb') as output:
                    shutil.copyfileobj(stream, output, 1024**2)
                loop = run(['losetup', '--find', '--show', '--read-only', image]).decode().strip()
                try:
                    readonly(loop)
                    with self.mounted(loop) as mount:
                        if name == 'metadata':
                            shutil.copytree(mount/'vold/metadata_encryption/key', self.job/'metadata-key')
                        else:
                            shutil.copytree(mount, self.job/'secure-store')
                finally:
                    run(['losetup', '-d', loop])
                    image.unlink()
        return hashes

    def android_files(self):
        # Read the existing environment through a read-only bounded env alias.
        with self.region('env') as env:
            config = self.job/'fw_env.config'
            config.write_text('%s 0x0 0x10000 0x10000\n' % env)
            slot = parse_active_slot(run(['fw_printenv', '-c', config, 'active_slot']).decode())
        result = {}
        with self.region('super') as device, device.open('rb', buffering=0) as stream:
            prefix = stream.read(12288)
            maximum, slots, _ = metadata_geometry(prefix)
            raw = prefix + stream.read(2*maximum*slots)
            for name in ('system', 'vendor'):
                for backup in (False, True):
                    try:
                        extents = vendor_extents(raw, size(device), slot, backup, partition_prefix=name)
                        break
                    except ValueError:
                        if backup:
                            raise ValueError('安卓动态分区元数据无效') from None
                validate_vendor_filesystem(stream, extents)
                offset, table = 0, []
                for sectors, start in extents:
                    table.append('%d %d linear %s %d' % (offset, sectors, device, start))
                    offset += sectors
                with self.mapping('\n'.join(table), offset*512) as mapped, self.mounted(mapped) as mount:
                    prop = mount/('system/build.prop' if name == 'system' else 'build.prop')
                    result[name] = dict(line.split('=', 1) for line in prop.read_text().splitlines()
                                        if '=' in line and not line.startswith('#'))
                    if name == 'vendor':
                        shutil.copyfile(mount/'lib/teetz/8efb1e1c-37e5-4326-a5d6-8c33726c7d57.ta', self.job/'keymaster.ta')
        props = result['system']
        if props.get('ro.product.system.model') not in ('A4111', 'A4112') or props.get('ro.build.version.release') != '11':
            raise ValueError('当前支持 4 Pro / 6S 原厂安卓 11 的配对存储')
        return props

    def pairings(self, props):
        key = unwrap_key(self.job/'metadata-key', props)
        try:
            with self.region('userdata') as raw:
                table = ('0 %d crypt aes-xts-plain64 %s 0 %s 0 2 sector_size:4096 iv_large_sectors'
                         % (size(raw)//512, key.hex(), raw))
                with self.mapping(table, size(raw)) as mapped:
                    del table
                    with mapped.open('rb', buffering=0) as stream:
                        if stream.read(4096)[1080:1082] != b'\x53\xef':
                            raise ValueError('无法解密安卓 data 元数据')
                    manifest = self.job/'manifest.jsonl'
                    def limits():
                        resource.setrlimit(resource.RLIMIT_FSIZE, (64*1024**2, 64*1024**2))
                    import subprocess
                    tool = self.job/'full-manifest'
                    shutil.copyfile(NATIVE, tool)
                    tool.chmod(0o700)
                    with manifest.open('wb') as output:
                        proc = subprocess.run([str(tool), str(mapped)], stdout=output,
                                              stderr=subprocess.DEVNULL, timeout=90, preexec_fn=limits)
                    if proc.returncode:
                        raise ValueError('只读安卓文件系统索引失败')
                    rows = {}
                    with manifest.open() as source:
                        if json.loads(next(source))['super']['block_size'] != 4096:
                            raise ValueError('当前 data 文件系统块大小尚未支持')
                        for line in source:
                            row = json.loads(line)
                            rows[row['inode']] = row
                            if len(rows) > 200000:
                                raise ValueError('安卓文件系统索引超过内存读取限制')
                    filesystem = Filesystem(mapped, raw, rows)
                    master = None
                    try:
                        record = {name: filesystem.read(filesystem.lookup('unencrypted', 'key', name))
                                  for name in ('version', 'stretching', 'encrypted_key', 'keymaster_key_blob', 'secdiscardable')}
                        master = unwrap_key(record, props)
                        filesystem.master = master
                        context(filesystem.lookup('misc'), master)
                        for parts in (('misc', 'bluedroid', 'bt_config.conf'),
                                      ('misc', 'bluetooth', 'bt_config.conf')):
                            try:
                                data = filesystem.read(filesystem.lookup(*parts)).decode('utf-8')
                            except KeyError:
                                continue
                            # Never silently substitute a possibly stale .bak pairing.
                            result = parse_android(data)
                            result['source'] = '/data/' + '/'.join(parts)
                            return result
                        raise ValueError('安卓当前蓝牙配对配置不存在')
                    finally:
                        if master is not None:
                            master[:] = bytes(len(master))
                        filesystem.close()
        finally:
            key[:] = bytes(len(key))


def acquire(job):
    identity = preflight()
    reader = Reader(job, identity)
    before = reader.key_copies()
    props = reader.android_files()
    # Load only the kernel's existing crypto module; no driver or firmware install.
    run(['modprobe', 'dm-crypt'])
    try:
        with factory_keymaster(job):
            result = reader.pairings(props)
    finally:
        after = {}
        for name in before:
            with reader.region(name) as source:
                after[name] = digest(source)
        if before != after:
            raise ValueError('原厂 metadata / TEE 分区发生变化，已停止导入')
    result.update(branch=identity['branch'], model=props['ro.product.system.model'],
                  android_unchanged=True, tee_restored=(job/'tee-restored').exists())
    return result
